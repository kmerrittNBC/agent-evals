# Durable Question-Clarification Runs Plan

## Goal and scope

Define a local-only, restart-safe contract between the Tauri/Lit desktop and its FastAPI sidecar for question-clarification runs. After restarting the desktop, a user should be able to reconnect to a run that is active, waiting for clarification answers, or complete, and see its saved progress and result.

This is a plan, not an implementation. It assumes no hosted production service, cloud database, or cloud credentials. It covers the current question-clarification and question-interpretation workflow; it does not design project/artifact storage or general workflow orchestration.

## Current flow and gap

- `apps/desktop/src/api/insight-specialist-api.ts` discovers the backend URL via Tauri's `get_backend_url()` or the Vite `/api` proxy. It starts runs, fetches snapshots, and posts clarification answers. Its helpers already use backend-relative run URLs.
- `apps/backend/src/insight_specialist_backend/main.py` exposes `POST /runs/question-clarification`, `GET /runs/{run_id}`, `GET /runs/{run_id}/events`, and `POST /runs/{run_id}/clarification-answers`.
- `apps/backend/src/insight_specialist_backend/runs.py` stores snapshots, events, and context in `InMemoryRunStore`. IDs are UUID4 hex strings. SSE IDs are per-run increasing integers and can replay from `?after=` or `Last-Event-ID`, but only while that backend process remains alive.
- `question_clarification_runs.py` starts daemon threads. A process exit loses both the store and its work. `BackendSidecarState` in `apps/desktop/src-tauri/src/backend_sidecar.rs` kills a child sidecar when Tauri exits.
- `InsightSpecialistApp` keeps run/snapshot/events and answers in Lit component state. `connectedCallback()` checks backend readiness but does not restore a run. Only notification preferences currently use localStorage.
- Existing tests cover in-memory run behavior, HTTP/SSE shape with optional live-LLM tests, frontend URL construction, and a mocked browser flow. They do not cover database reopen, application restart, or recovery.

There is also a status-model mismatch to resolve: the backend marks clarification as `succeeded` before it may accept user answers and start interpretation. `TERMINAL_STATUSES` then treats that as finished. A durable API should represent the user-input pause separately from successful completion of the overall run.

## Ownership options

| Option | Benefits | Costs / failure modes | Assessment |
| --- | --- | --- | --- |
| **FastAPI-owned SQLite run store; Lit persists only the selected run reference** | Matches the accepted architecture (`backend-framework-decision.md` and `system-architecture.md`); one authority for snapshots, results, context, events, and recovery; REST/SSE stays shared by browser and Tauri; survives WebView and backend process restarts. | Requires schema/versioning, app-data configuration, and worker recovery; interrupted model calls may need an at-least-once retry. | **Recommend.** This puts workflow persistence with the backend that already owns run semantics and model execution. |
| Tauri/Rust owns run records or a second run database | Native shell can supply the OS app-data path and access the DB across WebView reloads. | Duplicates workflow state and migrations in Rust; Rust would need to understand product statuses/results/events; conflicts with the thin-shell boundary; backend still needs durable state to recover work. | Reject as run owner. Tauri should only provide the app-data directory and shell lifecycle. |
| Lit/browser storage owns full snapshots/events, backend remains in-memory | Fast to prototype and needs no backend database. | Browser storage can be cleared, is unavailable to other clients, duplicates backend state, cannot recover a run whose server process vanished, and risks persisting sensitive workflow payloads in an unversioned UI cache. | Reject as source of truth. Use localStorage only for a small reconnect pointer/idempotency key, never the run itself. |

## Recommended boundary

1. **FastAPI owns authoritative run state.** Add a SQLite-backed implementation behind the existing run-store/service boundary. Use the OS app-data directory, not the repository checkout or working directory. Tauri derives/creates that directory and passes it to a spawned sidecar using a documented `INSIGHT_SPECIALIST_DATA_DIR` setting. A standalone backend uses the same documented platform default or an explicit setting. Tests always inject a temporary directory.
2. **Tauri stays a shell.** It continues backend discovery and process management, and only adds app-data path handoff. It must not read/write run tables or make workflow decisions. Do not change the existing configured/external-backend behavior silently: document that such a backend must point at the same durable data directory to reconnect to its runs.
3. **Lit stores a reconnect hint, not the run.** Persist a versioned pointer with the selected `backend_instance_id`, `run_id`, and `client_request_id` while a create request is outstanding. Keep the selected run ID after a successful response. On boot, fetch the authoritative snapshot; if necessary, use the recent-run endpoint to offer recovery. Treat localStorage as disposable and handle missing, malformed, or unavailable storage.
4. **Backend startup recovers work.** During FastAPI lifespan startup, inspect durable runs left in `running`. Requeue only the interrupted stage from a committed checkpoint under the same run ID and append a recovery event. Do not expose a run as actively `running` while no worker owns it. Recovery is at-least-once at model-call boundaries: if a process dies after a model returned but before its result transaction committed, that call may run again. Persist stage/attempt metadata and make this visible in the event history. Do not promise exactly-once model execution.
5. **Keep run data local.** Persist the raw question, current dataset profile, clarification answers, result, context ledger, and events only in the local DB with restrictive user-only file permissions where the OS supports them. Do not persist uploaded CSV contents as part of this work. Do not add cloud synchronization, remote run storage, credentials, or arbitrary CORS origins.

### Stable identifiers

- `run_id`: UUID4 lowercase 32-character hex, generated by the backend and retained across recovery. Keep the existing format for compatibility; do not derive it from question/file content.
- `client_request_id`: UUID4 generated by the desktop before `POST /runs/question-clarification`, sent as an `Idempotency-Key` header and retained until the response is resolved. The DB maps it to one request hash and one `run_id`; replay with the same key/body returns the same run, while reusing it with a different body returns `409`.
- `backend_instance_id`: stable UUID4 stored in DB metadata and returned by health/reconnect metadata. The UI pointer is scoped to this value so a pointer from another configured local backend is not mistaken for this backend's run.
- `event_id`: existing positive integer sequence, monotonically increasing per run; allocate it transactionally with the event row. Preserve IDs through recovery so SSE replay remains valid.
- `context_entry_id`: existing per-run ordered integer, transactionally allocated. Clarification-question IDs remain the stable IDs produced by the current schema, not DB row IDs.

### API contract additions/clarifications

- Preserve existing start, snapshot, answer, and SSE URLs and the existing fields. Make new fields additive; include `backend_instance_id` through health/reconnect metadata rather than moving workflow data into Tauri commands.
- Add `GET /runs?limit=<bounded>&before=<opaque-or-run-timestamp-cursor>` returning a newest-first page of snapshots/summary metadata, including active, awaiting-input, and recent terminal runs. Do not return an unbounded history by default.
- Keep `GET /runs/{run_id}` as the source for a complete current snapshot. Preserve event replay from `GET /runs/{run_id}/events?after=N` and Last-Event-ID. A fresh desktop may request from `after=0` to rebuild its event view; the SSE log must remain durable.
- Require an idempotency key for new-run creation from the updated client. Existing callers without the header may be accepted temporarily and assigned a backend-generated key during a compatibility window.
- Add `GET /run-requests/{client_request_id}` so a desktop that restarted after persisting a pending idempotency key but before receiving the create response can discover whether that request created a run. A missing request must not be silently recreated on startup; the UI can explain that the interrupted form needs to be submitted again.
- Make answer submission conditional on the run being `awaiting_input`; reject stale/duplicate conflicting submissions with `409`. An identical replay under the same answer-command idempotency key returns the current snapshot without appending context or starting another model call.
- Add a stable `error_code` and `retryable` field alongside the user-safe `error` message. Avoid leaking API keys, stack traces, or sensitive filesystem paths in HTTP errors or SSE. Detailed diagnostics, if retained, stay local and follow the existing privacy policy.

## Status and event model

Use the following persisted statuses:

```text
queued -> running -> awaiting_input -> queued -> running -> succeeded
queued -> running -> succeeded (no blocking answers needed)
running -> failed
```

- `queued`: durable work accepted but not yet owned by a worker, including requeued work after backend startup recovery.
- `running`: a worker owns an active stage.
- `awaiting_input`: clarification result is committed and the workflow is paused for required answers. It is resumable, not success or failure.
- `succeeded`: question interpretation finished (or the workflow's defined no-clarification path finished) and the complete result is committed.
- `failed`: a non-recoverable stage/API failure with a stable error code. Retrying a failed run is a future explicit feature, not an implicit transition.

On backend startup, an abandoned `running` record transitions to `queued` with a `run_recovered` event including the last committed stage and attempt number, then eligible work restarts using the same ID. Do not create a second run. A run waiting for user input remains `awaiting_input`; a completed/failed record remains terminal and is never rerun. If a checkpoint cannot be decoded or recovered, mark the run `failed` with `backend_recovery_failed` and preserve its prior event/context history.

Event sequence updates:

- Clarification that needs blocking user answers ends with `run_awaiting_input`, not `run_succeeded`; the SSE response may close at this stable pause. Answers append one context entry and `clarification_answers_received`, then start interpretation.
- Clarification with no blocking answers proceeds directly to interpretation (or the explicitly supported completion path) without exposing a false terminal success in between.
- Successful full workflow ends with `run_succeeded`; actual terminal failures end with `run_failed`.
- Preserve old events as history. For existing clients during rollout, accept historical `run_succeeded` snapshots with a clarification `spec` and no interpretation as legacy awaiting-input state in the UI.

All state changes that must agree (status/result/checkpoint, event, context entry, idempotency mapping) should commit in one SQLite transaction. Use foreign keys, a busy timeout, and WAL mode where supported; keep a single backend process/worker lease per DB so two sidecars cannot both recover the same run.

## Persistence and migration plan

1. Introduce a storage interface around current `InMemoryRunStore` calls and keep the in-memory implementation for fast unit tests. Add a SQLite implementation using Python's standard `sqlite3` unless repository dependency review establishes a need for an ORM.
2. Create an initial versioned schema with `runs`, `run_events`, `run_context_entries`, `idempotency_keys`, and DB metadata. Store JSON payloads as UTF-8 text and status/timestamps/sequence numbers as queryable columns. Keep timestamps UTC ISO-8601. Make startup migrations transactional and versioned with `PRAGMA user_version`; validate with `PRAGMA foreign_key_check` and `integrity_check`.
3. Establish app-data directory resolution before enabling persistence. Tauri should pass a per-user app data path to the child; standalone backend and tests should have deterministic documented defaults/overrides. Fail startup clearly rather than silently falling back to in-memory storage if the configured durable path cannot be created or opened.
4. Switch API construction to the SQLite store and add startup recovery. Keep endpoint response compatibility while adding `awaiting_input`, run listing, idempotency, and error fields.
5. Add frontend boot reattachment. Restore the pointer only after backend identity is checked, fetch the snapshot, then reconnect SSE. If the saved ID is missing (404), clear only the stale pointer and show a clear notice; use the recent-run list as a recovery route. A backend network failure must not erase the pointer.
6. Existing run storage is explicitly ephemeral today. There is no durable old DB to import: process restart already destroys all in-memory runs. Do not fabricate migration data or promise preservation for runs in a backend process that is stopped during upgrade. If upgrading a still-running development process is ever supported, that requires a separate export/import path and is not in this scope.
7. Before every schema upgrade, create a consistent local backup or a SQLite backup API snapshot. Retain a small documented number of backups, never delete the user's DB automatically, and report path/permissions/disk-full/integrity failures without returning sensitive path details to the UI.

## Error and recovery behavior

| Condition | Backend/API behavior | Desktop behavior |
| --- | --- | --- |
| Backend unavailable during startup | Existing Tauri readiness error; no DB deletion or pointer mutation. | Show reconnect/retry affordance and retain pointer/idempotency key. |
| Unknown saved run (`404`) | Return structured `run_not_found`; do not create a replacement implicitly. | Clear only the stale pointer after confirmation/notice; show recent-run recovery if available. |
| DB locked/busy | Bounded busy timeout, then structured retryable `503`; do not partially append status/event. | Keep run ID, retry snapshot/SSE with backoff, display reconnecting state. |
| Disk full, permission denied, corrupt DB, failed migration | Fail durable-store initialization or the write atomically; expose safe error code; preserve backup and DB for diagnosis. | Explain that local run storage is unavailable; never silently claim the run was saved. |
| Sidecar died during a stage | On next backend startup, recover from the last committed checkpoint, reuse run ID, append `run_recovered`, and rerun the in-flight stage at-least-once. | Fetch snapshot and resume SSE; display recovery/attempt history. |
| Invalid/missing answers or answer sent in wrong state | `400`/`422` for schema/required-answer validation; `409` for illegal state or conflicting duplicate. | Keep answers visible/editable; do not set the whole run to failed for a client validation/state conflict. |
| Model/schema stage failure | Commit `failed`, error code, safe error text, attempt, and failure event together. | Show persisted failure with prior context; do not lose the run pointer. |
| Duplicate create request after lost response | Idempotency lookup returns original run/snapshot; changed body with same key returns `409`. | Do not start a duplicate run; resume returned run ID. |
| Malformed localStorage or backend identity mismatch | Server remains authoritative; reject/ignore pointer only. | Recover recent runs or return to empty state without crashing. |

Use `404` for unknown IDs, `409` for state/idempotency conflicts, existing `400` or `422` conventions for invalid payloads (settle one in the implementation), `503` for temporary store unavailability, and `5xx` for unexpected backend/storage errors. Keep responses consistent with the current FastAPI `detail`-based client decoder while adding machine-readable error codes.

## Implementation sequence

1. **Contract and schema tests:** freeze status semantics, table constraints, ID rules, API response compatibility, and idempotency behavior with deterministic fixtures.
2. **Durable backend store:** implement schema migrations, transactional run/event/context writes, run listing, snapshot loading, and restart recovery. Preserve the in-memory store for isolated tests.
3. **Sidecar storage path:** add app-data path resolution/handoff and database health/readiness reporting; verify configured backend behavior stays explicit.
4. **API and recovery lifecycle:** wire persistence into FastAPI lifespan; add list/idempotent create and answer handling; correct awaiting-input/terminal event semantics.
5. **Desktop reconnection:** add typed API helpers and boot state loading; restore an active/awaiting/completed snapshot and replay/reconnect SSE; add recent-run fallback and non-destructive error states.
6. **Restart verification:** exercise the actual sidecar lifecycle with temporary databases and fake model clients, then manual Tauri restart checks. No live LLM is required for deterministic tests.

## Test plan and acceptance criteria

### Backend unit and API tests

- Create a run, write events/context/result, close the store, reopen the same temp DB, and assert snapshot, result, sequence numbers, and event replay are unchanged.
- Apply each schema migration from an empty DB and from the prior schema; assert transaction rollback on an injected migration/write error and verify integrity/foreign keys.
- Prove idempotent create with the same key/body returns the same ID, changed body returns `409`, and concurrent duplicate requests do not start two workers.
- Prove pending-request lookup returns the created run after a lost response and returns a clear not-found result when no request was committed.
- Prove answer idempotency, validation, and state conflict behavior; no duplicate context entry, event, or interpretation call on replay.
- Test each allowed/disallowed status transition, including clarification pause and final success; test old persisted success-with-spec snapshots map to legacy awaiting-input behavior.
- Simulate shutdown with a fake worker in `running`, reopen the store/service, assert recovery uses the same ID and committed checkpoint, and ensure a call interrupted before commit may be retried exactly as documented.
- Assert `awaiting_input`, `succeeded`, and `failed` are restored without rerunning work; an unrecoverable checkpoint becomes a preserved, readable failure.
- Test durable run listing pagination, unknown run `404`, SSE replay from zero and from an event cursor, and no event-ID gaps/duplicates after recovery.
- Inject read-only directory, locked DB, full/write failure, malformed stored JSON, and migration failure; assert atomic state and safe machine-readable errors.

### Desktop and cross-boundary tests

- API unit tests cover the new recent-runs endpoint, idempotency header, snapshot lookup, and URL resolution in browser `/api` and Tauri direct-backend modes.
- Mocked Lit UI tests reload the app with a pointer to a running run, an awaiting-input run, a completed run, a failed run, a missing run, malformed storage, and a temporarily unreachable backend. Check the same run ID is shown and no duplicate create call occurs.
- Verify restored clarification answers/results render correctly, event history is rehydrated, and SSE resumes without duplicate displayed events.
- Backend integration tests use a temporary DB and fake model client, kill/restart the backend process mid-run, and verify the same ID is reattached and completed/recovered without cloud credentials or live model calls.
- Tauri/manual test: start a run, close/restart the desktop while clarification and interpretation are in flight, reopen, verify recovery and event history; repeat with a run awaiting answers and a completed run. Also verify a different `backend_instance_id` does not attach the wrong pointer.
- Continue running existing browser tests against the mocked backend and existing Tauri smoke tests; test the migration with an existing DB fixture.

Acceptance is: a fresh desktop can identify and fetch the last selected run from the backend, stream/replay its events, display its current status/result, and (for an interrupted active stage) requeue it under the same ID after backend restart. The behavior must remain local and deterministic in tests.

## Rollback

- Keep this change additive at the HTTP boundary and retain the in-memory store as a test/development implementation. Do not delete or overwrite SQLite data when disabling durable storage.
- Gate the new store/recovery path with an explicit local setting during rollout (default to SQLite after verification); a fallback to memory must be clearly marked ephemeral and must never happen silently after a SQLite open/write error.
- On a migration or recovery defect: stop the sidecar, preserve the DB and its backup, disable automatic recovery if necessary, and fix forward or restore the last verified backup using SQLite's backup procedure. Do not downgrade by deleting the DB.
- An older desktop/backend build that only supports in-memory state cannot reconnect to SQLite-backed run history. If rollback is needed, disclose this limitation and preserve the database untouched for a later compatible build; do not claim that old runs were migrated into memory.
- Keep API compatibility for existing start/snapshot/answer fields, and retain the legacy clarification-result interpretation path for one release/test cycle. Remove compatibility only in a separately documented contract change.

## Local verification to run when implemented

No application code is changed by this plan. At implementation time, follow `docs/authoritative/engineering/verification/backend.md`, `desktop-frontend.md`, and `tauri-shell.md`:

```bash
(cd apps/backend && .venv/bin/python -m pytest tests/unit)
(cd apps/backend && .venv/bin/python -m pytest tests/integration)
(cd apps/desktop && pnpm test && pnpm run build && pnpm run test:ui)
(cd apps/desktop && pnpm run test:desktop)
(cd apps/desktop/src-tauri && cargo test && cargo check)
```

Run tests with fake model clients and temporary DBs by default. Live-LLM checks are optional and must not be required for restart, migration, or recovery coverage.
