# Durable Question-Clarification Run Boundary

## Status

Proposed plan. Nothing in this document describes current behavior. When a phase ships, move what it decided into the authoritative docs listed under [Documentation Updates](#documentation-updates) and mark that phase done here.

## Goal

A desktop restart must be able to reconnect to a question-clarification run, whether it was still running or already finished, and show the same step, results and event history as before the restart. A run that was cut off must say so clearly and offer a way to continue.

Scope is local only: the Tauri/Lit desktop, the local FastAPI sidecar, and a local file in the app data directory. No remote production service, cloud storage or cloud credentials are assumed. The model endpoint stays the existing OpenAI-compatible URL from backend environment variables.

## Current State (Inspected 2026-10-15)

### Backend

- `apps/backend/src/insight_specialist_backend/runs.py`: `InMemoryRunStore` keeps `_RunRecord`s in a process-local dict guarded by one `threading.Condition`. Run ids are `uuid4().hex`. Event ids and context-entry ids are per-run integers starting at 1 (`len(...) + 1`). `RunNotFoundError` is documented as "not known to the current backend process".
- `RunStatus = queued | running | succeeded | failed`; terminal = `{succeeded, failed}`. `iter_sse_events` replays events after `after_id`, sends heartbeats, and closes on terminal status.
- `apps/backend/src/insight_specialist_backend/question_clarification_runs.py`:
  - `start_run` creates the run and starts a daemon thread for clarification.
  - After clarification the run is marked **`succeeded`**, even when `spec.should_ask_user` is true and the workflow is waiting for the user.
  - `submit_clarification_answers` calls `mark_running` on that `succeeded` run, so a terminal status goes back to non-terminal. It also has no status guard: a second submit (double-click, or a retry after a restart) starts a second interpretation thread.
  - Answer submission is spread over four separate store calls (`update_result`, `append_context_entry`, `append_event`, `mark_running`). A crash between them leaves partial state.
  - Errors are stored only as `str(error)`. There is no error category.
- `main.py`: one module-level `run_store = InMemoryRunStore()`. `/health` reports no store information.

### Desktop shell (Rust)

- `apps/desktop/src-tauri/src/backend_sidecar.rs` and `main.rs`: if no backend is healthy at `:8765`, the shell spawns uvicorn and **kills that child on window close or app exit**. Externally started backends are left running.
- Result: in the default desktop path, closing the app ends the backend process. All runs, including any in-flight model call, are lost. Even with an external backend, the desktop forgets which run it was showing.

### Desktop frontend

- `apps/desktop/src/api/insight-specialist-api.ts` has `startQuestionClarificationRun`, `getRunSnapshot` and `submitClarificationAnswers`. Errors are plain `Error(detail)` with no HTTP status, so callers can't tell 404 from 409 from a network failure.
- `apps/desktop/src/components/insight-specialist-app/insight-specialist-app.ts` keeps all run state in Lit `@state` fields (`run`, `snapshot`, `events`, `activeStep`, `submittedQuestion`, `submittedFileName`, `clarificationAnswers`). Nothing is persisted, so a reload or restart lands on an empty "define" step.
- The step is worked out in two places that can drift apart: `updateActiveStepFromEvent` (live events) and `loadSnapshot` (`question_interpretation` → interpret, `should_ask_user` → clarify).
- `RUN_EVENT_TYPES` does not include `clarification_answers_received`, so that event never reaches the feedback panel.
- `submittedFileName` exists only in the UI. The backend never receives it, so a restore can't show it.
- `apps/desktop/src/preferences/notification-preferences.ts` is the existing pattern for versioned `localStorage` state with an injectable `Storage`.

### Docs already committed to this direction

- [system-architecture.md](../../authoritative/architecture/system-architecture.md) and [backend-framework-decision.md](../../authoritative/architecture/backend-framework-decision.md): SQLite in the app data directory for run metadata.
- [vertical-slice-boundaries.md](../../authoritative/architecture/vertical-slice-boundaries.md) criterion 6: "The backend owns run state, stage transitions, ... and persisted snapshots". The required follow-up is to persist run state outside the in-memory store.
- [local-backend.md](../../authoritative/backend/local-backend.md): "Later SQLite persistence should preserve this append-only shape" for the context ledger.

## Ownership Options

### Option A: the backend owns durable runs; the desktop keeps only a pointer (recommended)

The backend writes every run, event and context entry to SQLite in the app data directory. The desktop persists only a small pointer saying which run this window last had open. On startup it re-reads the run over the existing HTTP/SSE contract.

- Pros:
  - Matches vertical-slice criterion 6 and the SQLite decision record.
  - There is one source of truth.
  - Browser-run and Tauri paths use the same code.
  - SSE `Last-Event-ID` replay already exists and becomes meaningful across restarts.
  - Future steering/follow-up endpoints get durability for free.
- Cons:
  - Needs a storage abstraction, a schema, migrations and crash recovery in the backend.
  - An in-flight model call still dies with the process, so "in progress" across a sidecar restart means "interrupted, resumable", not "still running".

### Option B: the desktop owns a run cache

The frontend writes the snapshot plus its event list to `localStorage` (or a Tauri store) after every event and re-renders from the cache on startup. The backend stays in-memory.

- Pros: no backend change; fast to build.
- Cons:
  - Breaks criterion 6 by creating a second copy of run state that can disagree with the backend.
  - Can't continue a run: after a sidecar restart the backend has no record, so answers can't be submitted and interpretation can't run.
  - The browser origin (`127.0.0.1:<port>`) and the Tauri WebView keep separate caches.
  - The context ledger, which later prompts rebuild from, would be lost or would need re-uploading.

Rejected as the source of truth.

### Option C: the shell keeps the backend alive

Change `backend_sidecar.rs` so the spawned backend outlives the desktop (detached daemon), and keep the in-memory store.

- Pros: a run that is truly in progress keeps running while the desktop is closed. Small Rust change.
- Cons:
  - Durable only until the backend crashes, the machine reboots or the user logs out.
  - Leaves orphan Python processes holding port 8765.
  - Moves lifecycle policy into Rust and changes the documented "Tauri kills only the child it started" rule.
  - Still needs a desktop pointer.

On its own it doesn't meet the goal. It can be layered on Option A later (see [Open Questions](#open-questions)).

### Decision

Adopt **Option A** and leave the sidecar lifecycle unchanged. Restarts are handled by:

1. making each run state change durable and atomic,
2. at backend startup, marking runs whose worker died as `interrupted`,
3. an explicit resume command.

This plan needs no Rust changes.

#### Storage under Option A

SQLite through the standard-library `sqlite3` module, matching the decision record and adding no dependency. An append-only JSONL file per run was considered. It is simpler to append to, but it has no atomic multi-row transitions, no indexed listing, and needs its own compaction. Rejected.

## Target Contract

### Identifiers

| ID | Format | Assigned by | Purpose |
| --- | --- | --- | --- |
| `run_id` | `uuid4().hex` (32 lowercase hex), unchanged | backend | Primary key; opaque to clients. Path params not matching `^[0-9a-f]{32}$` return 404 without a DB lookup. |
| `store_id` | `uuid4().hex`, written once into the DB `meta` table when the DB is created | backend | Identifies the run database. Returned by `/health` and stored in the desktop pointer, so a wiped or different data dir is detected instead of producing confusing 404s. |
| event `id` | Per-run integer, strictly increasing from 1, assigned in the same transaction as the write | backend | SSE `id:` and `Last-Event-ID` / `?after=`. Unchanged wire format. |
| context entry `id` | Per-run integer from 1, same transaction rules | backend | Ledger order; unchanged wire format. |
| `client_request_id` | UUID v4 string generated by the desktop | desktop | Idempotency key on `POST /runs/question-clarification` and `POST /runs/{id}/clarification-answers`, sent as the `Idempotency-Key` header. It must be added to the CORS `allow_headers`. Unique per `(run_id or kind, operation)`. |
| `attempt` | Integer from 1 per stage execution | backend | Included in `stage_*` and `model_call_*` payloads. Goes up on resume so logs and ablation runs can be explained. |
| `schema_version` | SQLite `PRAGMA user_version` | backend | Migration gate. |

### Status model

New `RunStatus = queued | running | awaiting_input | interrupted | succeeded | failed`.

- **Terminal** (no further transitions): `succeeded`, `failed`.
- **Stream-closing** (SSE ends because no backend work is in progress): `awaiting_input`, `interrupted`, `succeeded`, `failed`.

New run fields:

- `current_stage`: `question_clarification | question_interpretation | null`
- `error_code`: see [Error handling](#error-handling)

`error` stays a human-readable string.

Allowed transitions. Any other transition raises `InvalidRunTransition`, which maps to HTTP 409.

| From | To | Trigger | Event(s) emitted (same transaction) |
| --- | --- | --- | --- |
| (none) | `queued` | `POST /runs/question-clarification` | `run_created` |
| `queued` | `running` | worker picks up clarification | `run_started`, `stage_started` |
| `running` | `awaiting_input` | clarification stage succeeds | `model_call_succeeded`, `stage_succeeded`, `run_awaiting_input` {`stage`, `blocking_question_count`} |
| `awaiting_input` | `queued` | valid `POST .../clarification-answers` | `clarification_answers_received` |
| `queued` | `running` | worker picks up interpretation | `run_started`, `stage_started` |
| `running` | `succeeded` | interpretation stage succeeds | `model_call_succeeded`, `stage_succeeded`, `run_succeeded` |
| `running` | `failed` | stage raises | `stage_failed`, `run_failed` {`error`, `error_code`} |
| `queued`/`running` | `interrupted` | backend startup recovery sweep finds a run with no live worker | `run_interrupted` {`previous_status`, `stage`, `reason: "backend_restarted"`} |
| `interrupted` | `queued` | `POST /runs/{id}/resume` | `run_resumed` {`stage`, `attempt`} |
| `interrupted` | `failed` | `POST /runs/{id}/abandon` (optional, phase 3) | `run_failed` {`error_code: "abandoned"`} |

Notes:

- Clarification always ends in `awaiting_input`, even when `should_ask_user` is false. This keeps the explicit Autonomy Handoff from [failure-and-handoff.md](../../authoritative/ux/failure-and-handoff.md): the user confirms before interpretation starts. This replaces today's `run_succeeded` after clarification and fixes the terminal → running reversal.
- `run_succeeded` now means the whole question workflow is finished.
- The resume stage is derived from durable state:
  - no `question_clarification` context entry → rerun clarification;
  - otherwise → rerun interpretation.
- Stages are single model calls, so re-execution is the resume unit. Partial model output is never persisted.

### API surface (additive)

```text
GET  /health                                → adds store {backend: "sqlite"|"memory", durable: bool, store_id, schema_version, error?} and capabilities: ["durable_runs", "run_resume"]
POST /runs/question-clarification           → accepts Idempotency-Key; body adds optional source_file_name (basename only)
GET  /runs/{run_id}                         → adds current_stage, error_code, last_event_id, store_id
POST /runs/{run_id}/clarification-answers   → accepts Idempotency-Key; 409 unless status == awaiting_input (or same key replay)
POST /runs/{run_id}/resume                  → 202; 409 unless status == interrupted
GET  /runs?kind=&status=&limit=             → newest-first summaries (run_id, kind, status, current_stage, created_at, updated_at); default limit 20, max 100
GET  /runs/{run_id}/events                  → unchanged wire format; closes on stream-closing statuses
```

Idempotency rules:

- The same key with the same body returns the original response with HTTP 200.
- The same key with a different body returns 409 `idempotency_key_reused`.
- Keys live in an `idempotency_keys` table: `(key PRIMARY KEY, operation, run_id, request_hash, created_at)`.

### Storage

- **Location:** `INSIGHT_SPECIALIST_DATA_DIR` if set. Otherwise the documented app data path (`$XDG_DATA_HOME/insight-specialist` or `~/.local/share/insight-specialist` on Linux; the macOS and Windows paths from `system-architecture.md`). The backend computes this, so browser-run and Tauri-spawned backends use the same DB. The Rust shell passes nothing in this plan. If `get_app_data_dir()` is added later, it should pass the same path through this env var.
- **Files:**
  - `runs.sqlite3`, created with permissions `0600` inside a `0700` directory;
  - `runs.lock`.
- **Switch:** `INSIGHT_SPECIALIST_RUN_STORE=sqlite|memory`, default `sqlite` after phase 2. This is the ablation switch and the runtime rollback lever.
- **Tables:**
  - `meta(key, value)`
  - `runs(run_id PK, kind, status, current_stage, created_at, updated_at, input_json, result_json, error, error_code)`
  - `run_events(run_id, id, type, timestamp, payload_json, PK(run_id, id))`
  - `run_context_entries(run_id, id, step, actor, entry_type, timestamp, content_json, PK(run_id, id))`
  - `idempotency_keys(...)`
  - an index on `runs(updated_at)`
- **Connection settings:** `journal_mode=WAL`, `synchronous=NORMAL`, `foreign_keys=ON`.
- **Atomicity:** every service operation that changes a run uses one `store.transaction(run_id)` covering the row update, events and context entries. In-process SSE wake-ups (`Condition.notify_all`) fire only after commit. The four-call answer submission becomes one transaction.
- **Single writer:** at startup the store takes an exclusive advisory lock on `runs.lock` (`fcntl.flock` / `msvcrt.locking`) and holds it for the life of the process.
  - Only the lock holder may run the recovery sweep. Without the lock, a second backend pointed at the same DB (for example via `INSIGHT_SPECIALIST_BACKEND_URL` on another port) would mark the first backend's live runs `interrupted`.
  - If the lock is held by another process, the store degrades (see the next item).
- **Degraded mode:** if the DB can't be opened, migrated or locked, the backend still starts with an in-memory store and reports `/health.store = {backend: "memory", durable: false, error}`.
  - This is never silent. The desktop shows a persistent "Runs will not survive a restart" warning.
  - It is necessary because the sidecar's stdout and stderr go to `Stdio::null()`, so a startup crash would only show as a health timeout.
- **Abstraction:** a `RunStore` `Protocol` with `InMemoryRunStore` and `SqliteRunStore`. `QuestionClarificationRunService` and `iter_sse_events` depend only on the protocol, and `main.py` picks the implementation from config.
- **Privacy:** what gets persisted (raw question, schema-only dataset profile, model outputs, answers) is already "stored locally" under [security-privacy.md](../../authoritative/architecture/security-privacy.md). Nothing leaves the machine because of this change. `source_file_name` is a basename, never a full path.

### Desktop state flow

- **Run pointer:** new module `src/workflow/run-pointer.ts`, following the `notification-preferences.ts` pattern.
  - Key: `insight-specialist.active-run.v1`.
  - Value: `{ run_id, store_id, saved_at }`.
  - `load` tolerates malformed JSON and returns `null`.
  - Saved right after `startQuestionClarificationRun` resolves. Cleared on "Start new run".
  - `run_url` and `events_url` are rebuilt from `run_id` and not trusted from storage.
- **Restore sequence** in `connectedCallback`, after `resolveApiBaseUrl()`:
  1. `GET /health`. If `durable_runs` isn't in `capabilities`, skip the restore and keep the pointer.
  2. Load the pointer. If it's missing, show the define step as today.
  3. If `pointer.store_id !== health.store.store_id`, clear the pointer and show a notice ("The previous run belongs to a different run database").
  4. `GET /runs/{id}`:
     - 404 → clear the pointer and show a notice;
     - network error → keep the pointer and show the existing backend error with a retry action.
  5. Apply the snapshot through a pure `deriveViewState(snapshot)` that returns `{ status, activeStep, clarificationAnswers, submittedQuestion, submittedFileName }`.
  6. Open SSE from `after=0` to rebuild the feedback-panel event list. For stream-closing statuses the backend replays and closes at once. For `queued`/`running` the stream stays open.
- **One derivation path:** the live terminal and stream-closing handlers also call `deriveViewState` after `loadSnapshot`, so restored and live state can't drift. `updateActiveStepFromEvent` keeps only the in-flight hint (switching to a step when its `stage_started` arrives).
- **Event list:** `RUN_EVENT_TYPES` gains `clarification_answers_received`, `run_awaiting_input`, `run_interrupted` and `run_resumed`. `TERMINAL_EVENTS` becomes stream-closing events. Events are de-duplicated by `id` so a reconnect replay can't double-count model calls.
- **Interrupted UI:** a notice in the clarify or interpret panel, following the "what succeeded / what failed / what's next" structure of [failure-and-handoff.md](../../authoritative/ux/failure-and-handoff.md), with a **Resume** button (`POST /resume`, then reopen SSE with `after=last_event_id`).
- **API client:**
  - `decodeJsonResponse` throws `BackendHttpError { status, detail, code }`, a subclass of `Error`, so existing `message` use keeps working. Callers branch on `status` instead of matching message strings.
  - New `getHealth`, `resumeRun` and `listRuns` functions.
  - `startQuestionClarificationRun` and `submitClarificationAnswers` take an `idempotencyKey`, generated with `crypto.randomUUID()` once per user action and reused on retry.
- **Types:** `RunSnapshot.status` and `RunStartResponse.status` become the `RunStatus` union. Add `current_stage`, `error_code`, `last_event_id` and `store_id`. Add `source_file_name` to `QuestionClarificationPayload`.

## Error Handling

| Condition | Backend behavior | Desktop behavior |
| --- | --- | --- |
| Model call fails / schema invalid | `failed`, `error_code` `model_unavailable` / `schema_validation` | Existing failed state; show `error` |
| Unexpected exception in worker | `failed`, `error_code: internal`; traceback goes to the log, not the API | Same |
| Backend process dies mid-stage | On next startup the sweep moves the run to `interrupted` with `run_interrupted` | Restore shows the Interrupted notice and the Resume button |
| Answers posted while not `awaiting_input` | 409 `invalid_transition` with current `status` | Re-fetch the snapshot, re-derive the view, show "This run already moved on" |
| Duplicate answers (same key) | 200 with original response; no second worker | Normal flow |
| Same idempotency key, different body | 409 `idempotency_key_reused` | Treat as a bug: show the error and generate a new key on the next user action |
| Unknown or malformed `run_id` | 404 | Clear the pointer and show a notice |
| `store_id` mismatch | n/a | Clear the pointer and show a notice |
| DB unopenable / locked / newer `schema_version` than the code knows | Degrade to memory and report `durable: false` with `error`. Never downgrade or rewrite a newer DB | Persistent warning banner; skip restore |
| Write fails (disk full, I/O) | Transaction rolls back; HTTP 503 `store_unavailable`. A worker that can't record its result tries `failed`; if that also fails, the next startup sweep marks the run `interrupted` | Show the error; the pointer is kept |
| SSE drops while `queued`/`running` | n/a | Let `EventSource` auto-retry (it sends `Last-Event-ID`). After 3 consecutive `onerror`s, fetch the snapshot. If the backend is unreachable, show the existing "Lost the run event stream" error with a reconnect action |
| `localStorage` unavailable or corrupt | n/a | `load` returns `null`; the app starts fresh |

## Migration

1. **Data:** nothing to migrate. Runs are only in memory today, so runs in flight at upgrade time are lost once. Note this in the release/dev log.
2. **Schema:** forward-only migrations in `insight_specialist_backend/run_store_migrations.py`, keyed by `user_version` (0 → 1 creates the tables and the `meta.store_id`). They run at startup while holding the lock. Before any migration on a non-empty DB, copy `runs.sqlite3` to `runs.sqlite3.bak-v<old>`. A `user_version` greater than the code knows triggers degraded mode, never a downgrade.
3. **API semantics:** two changes are not additive:
   - clarification now ends `awaiting_input` instead of `succeeded`;
   - stream closing is keyed on the new set.

   The backend change, the frontend handling, and both mock backends (`apps/desktop/tests/ui/harness.mjs` and the desktop smoke mock used by `tests/desktop/tauri-smoke.test.mjs` / `scripts/desktop-smoke.mjs`) **must ship in the same PR** (phase 1). Everything else is additive and gated by `/health.capabilities`.
4. **Config:** new env vars `INSIGHT_SPECIALIST_DATA_DIR` and `INSIGHT_SPECIALIST_RUN_STORE`, documented in `local-backend.md`, with defaults that need no developer action.

## Phases

Each phase is one Gitea issue under a `type/epic` parent, following [work-tracking.md](../../authoritative/engineering/work-tracking.md).

1. **Status model and atomic transitions (in-memory).**
   - Backend: the `RunStatus` additions, a transition table with `InvalidRunTransition` → 409, `store.transaction`, idempotency keys, `error_code`, `current_stage`, `run_awaiting_input`.
   - Frontend and both mock backends: handle the new events and statuses, `BackendHttpError`, `deriveViewState`.
   - Fixes the double-submit bug without persistence.
2. **SQLite run store.** The `RunStore` protocol, `SqliteRunStore`, migrations, data dir config, lock, degraded mode, recovery sweep, `/health.store`, the `INSIGHT_SPECIALIST_RUN_STORE` switch.
3. **Resume and listing.** `POST /resume`, the optional `POST /abandon`, `GET /runs`, `attempt` in payloads.
4. **Desktop restore.** The run pointer, the restore sequence, the Interrupted UI, event de-duplication, the capability gate.
5. **Desktop verification and docs.** The Tauri smoke restart case, the manual test plan, the authoritative doc updates.

## Tests

### Backend unit (`apps/backend/tests/unit`, stdlib `unittest`, no network)

- **Store contract suite:**
  - run once against `InMemoryRunStore` and once against `SqliteRunStore` (in a temp dir), sharing the same assertions;
  - covers create/get, ordered event and context ids, `events_after`, `wait_for_events_after` wake-up, and `wait_for_terminal`.
- **Transition table:**
  - every allowed transition succeeds and emits the listed events;
  - every other `(from, to)` pair raises `InvalidRunTransition` and leaves state unchanged.
- **Durability:**
  - write a run through each status, close the store, open a new `SqliteRunStore` on the same dir, and assert equal snapshots, events and context;
  - SSE `iter_sse_events` from `after=N` against the reopened store yields only events after `N`.
- **Recovery sweep:**
  - `queued` and `running` runs become `interrupted` with exactly one `run_interrupted` event;
  - `awaiting_input`, `succeeded` and `failed` are untouched;
  - a second sweep is a no-op.
- **Lock:** a second store on the same dir gets degraded mode and never sweeps.
- **Atomicity:** patch the event insert to raise during answer submission and assert that the result, context, events and status are all unchanged.
- **Idempotency:**
  - a replayed create returns the same `run_id` and starts no second worker (`FakeModelClient.calls` length);
  - replayed answers start one interpretation;
  - a reused key with a different body returns 409.
- **Double submit:** the second answers POST with a new key while `queued`/`running` returns 409 and only one interpretation call.
- **Resume:**
  - an interrupted run with no clarification entry reruns clarification;
  - one with a clarification entry reruns interpretation;
  - `attempt` is 2 in both cases.
- **Migrations:**
  - a fresh DB reaches `user_version` 1 and gets a `store_id`;
  - an existing v1 DB is a no-op;
  - `user_version` 99 degrades and leaves the file byte-for-byte unchanged;
  - a backup file is created before a real migration.
- **Config:** `INSIGHT_SPECIALIST_DATA_DIR` and `INSIGHT_SPECIALIST_RUN_STORE` parsing; an invalid value raises a clear `ValueError` like the existing `_int_from_env`.
- **Privacy:** `/health.store` never includes file contents or the API key, and the DB file mode is `0600`.
- **FastAPI routes** (`test_main.py`, needs `fastapi`): 404 for malformed ids, 409 mapping, CORS preflight allows `Idempotency-Key`.

### Backend integration (`apps/backend/tests/integration`)

- New `test_run_restart_recovery.py`, which runs without a live LLM:
  - start a stdlib `http.server` OpenAI-compatible stub on loopback that delays its response;
  - start uvicorn with a temp `INSIGHT_SPECIALIST_DATA_DIR`, create a run, wait for `model_call_started`, then `SIGKILL` uvicorn;
  - restart uvicorn on the same dir. Assert `GET /runs/{id}` returns `interrupted`, SSE replay is intact and ends with `run_interrupted`, and `POST /resume` reaches `awaiting_input`;
  - kill and restart again, then assert the `awaiting_input` snapshot is unchanged and answers lead to `succeeded`.
- Extend the existing live `test_question_clarification_run_api.py` for the `awaiting_input` status. It stays gated by `INSIGHT_SPECIALIST_RUN_LLM_INTEGRATION_TESTS=1`.

### Frontend unit (`apps/desktop/tests/unit`, vitest)

- `run-pointer.test.ts`: round-trip, malformed JSON, missing fields, versioned key, injectable `Storage`.
- `derive-view-state.test.ts`: one case per status, with and without `question_interpretation` and `accepted_answers`.
- `api.test.ts` additions:
  - `BackendHttpError` carries status, detail and code;
  - the `Idempotency-Key` header is sent and reused across a retry;
  - `getHealth`, `resumeRun` and `listRuns` build URLs correctly in both `/api` and Tauri modes.

### Browser UI (`apps/desktop/tests/ui`, WebDriver plus a mock backend that gains persistent in-process state across page reloads)

- Reload while `running`:
  - the same run is restored;
  - SSE reconnects;
  - the feedback panel shows each event once.
- Reload at `awaiting_input` → clarify step with the questions and the restored question and file name.
- Reload after `succeeded` → interpret step with `churn_driver_analysis`.
- Pointer to an unknown run, and pointer with a `store_id` mismatch → define step plus a notice; pointer cleared.
- `interrupted` → Resume → completes.
- Mock `/health` without `durable_runs` → no restore attempted (backward compatibility).
- Mock `durable: false` → warning banner.

### Desktop (`apps/desktop/tests/desktop`, tauri-driver against the mock backend through `INSIGHT_SPECIALIST_BACKEND_URL`)

- Start a run to `awaiting_input`, end the Tauri session, start a new session against the same mock, and assert the clarify step is restored. This proves the WebView `localStorage` survives an app restart for this app identifier.

### Manual test plan (to add to `desktop-shell.md` in phase 5)

1. Run `pnpm run tauri:dev` with no external backend. Start a run and close the app during "Model calls 1".
2. Relaunch. Confirm the Interrupted notice appears, then Resume reaches the clarify step.
3. Answer the questions, wait for interpretation, close and relaunch. Confirm the interpret step is shown without any new model call (check the vLLM request log or the event count).
4. Delete `~/.local/share/insight-specialist/runs.sqlite3` with the app closed, then relaunch. Confirm the "previous run is no longer available" notice and a clean define step.
5. Run `chmod 000` on the data dir, then relaunch. Confirm the "Runs will not survive a restart" banner and that a run still completes.

### Rust

No code change is planned. Re-run `cargo check` and `cargo test` to confirm.

## Rollback

- **At runtime, no code change:** set `INSIGHT_SPECIALIST_RUN_STORE=memory`.
  - The backend reports `durable: false` and drops `durable_runs` from its capabilities, so the desktop skips the restore.
  - This brings back today's behavior apart from the phase 1 status semantics.
- **Frontend only:** the restore is gated on `/health.capabilities`. Reverting the phase 4 PR leaves a durable backend that the UI simply doesn't restore from.
- **Backend phases 2 and 3:** revert the PRs.
  - The `runs.sqlite3` file stays in the data dir and is harmless.
  - Because migrations are forward-only and the code refuses newer `user_version`s, re-applying the change later reads the same file safely.
  - Document the manual cleanup path: delete `runs.sqlite3*` and `runs.lock` with the backend stopped.
- **Phase 1** changes status semantics on both sides. Roll it back as a whole PR (backend, frontend and mocks together), never partially. An older UI paired with a newer backend would wait forever for `run_succeeded` after clarification.
- **Data safety:**
  - no phase deletes or rewrites user files;
  - migrations take a backup first;
  - degraded mode never touches an unreadable DB.

## Documentation Updates (at implementation time)

- `docs/authoritative/backend/local-backend.md`: the status model, transition table, new events and endpoints, idempotency, storage location and env vars, degraded mode, and recovery sweep. Remove "stores runs in memory".
- `docs/authoritative/architecture/vertical-slice-boundaries.md`: remove the "temporary backend store" shortcut and tick off the persistence follow-up.
- `docs/authoritative/architecture/desktop-shell.md`: restart and restore behavior plus the new manual test steps. The sidecar lifecycle rule stays the same.
- `docs/authoritative/ux/interaction-lifecycle.md` and `failure-and-handoff.md`: the restore and Interrupted/Resume UX.
- `docs/authoritative/engineering/verification/backend.md`: the restart-recovery integration test, and the point that it needs no live LLM.
- `docs/authoritative/testing/frontend-browser-ui.md`: the reload scenarios and the mock backend's persistence.

## Out Of Scope

- Keeping the sidecar alive after the desktop closes (Option C).
- Cancelling runs.
- Multiple windows sharing one run.
- Retention and pruning of old runs.
- Backend-owned dataset ingest and project folders.
- Any remote or cloud service.

## Open Questions

1. **Default resume policy.** This plan defaults to manual Resume, so restarting the desktop never causes a model call by itself. An `INSIGHT_SPECIALIST_RUN_RECOVERY=manual|auto` switch could re-queue interrupted runs automatically, which fits the "don't make the user come back to a stalled run" principle. Should `auto` become the default once the recovery tests are stable?
2. **Detached sidecar.** Should a later issue add Option C, behind a setting, so that runs which are actually running continue while the desktop is closed?
3. **Retention.** How long are runs kept, and does the user get a "Recent runs" list using `GET /runs`? The endpoint ships in phase 3; the UI is deferred.

## Verification Of This Plan (2026-10-15)

- Docs-only change: this file plus one index line in `docs/speculative/plans/README.md`. No code changed.
- Ran from the worktree root with system `python3` 3.14.7, since `apps/backend/.venv` is absent: `PYTHONPATH=apps/backend/src:. python3 -m unittest apps.backend.tests.unit.test_runs apps.backend.tests.unit.test_config apps.backend.tests.unit.test_question_clarification apps.backend.tests.unit.test_question_interpretation apps.backend.tests.unit.test_model_client`. Result: 28 tests OK. This confirms the current run-store behavior described above.
- `apps.backend.tests.unit.test_main` could not import: `ModuleNotFoundError: No module named 'fastapi'`, because there is no backend venv in this worktree.
- Frontend `pnpm test` / `build` / `test:ui` / `test:desktop` and `cargo test` were not run. `apps/desktop/node_modules` is absent, `pnpm` is not on `PATH`, and no frontend or Rust files changed.
