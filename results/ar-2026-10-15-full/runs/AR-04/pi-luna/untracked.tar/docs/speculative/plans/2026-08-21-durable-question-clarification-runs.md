# Plan: Durable question-clarification runs across desktop restarts

## Goal and non-goals

Make a question-clarification run discoverable and reconstructable after the Lit/Tauri window closes and reopens, including a run that is still executing and one that has finished. Keep the backend local; this design requires neither a remote production service nor cloud credentials. The FastAPI backend remains the authority for workflow state, results, context, and progress. The frontend retains only enough local metadata to find and resume a run.

This is a plan, not an implementation. It does not make arbitrary Python/model calls resumable after a machine crash, persist CSV contents, or introduce project/account synchronization. A process crash during a model request is ambiguous; the plan reports that run as interrupted rather than silently repeating a possibly billable/non-idempotent call.

## Current flow and gap

Inspected current surfaces:

- `apps/desktop/src/api/insight-specialist-api.ts`: starts at `POST /runs/question-clarification`, fetches `GET /runs/{id}`, submits answers to `POST /runs/{id}/clarification-answers`, and resolves browser paths through Vite `/api` versus Tauri's `get_backend_url` command.
- `apps/backend/src/insight_specialist_backend/main.py`: owns the run endpoints and module-global `InMemoryRunStore`.
- `apps/backend/src/insight_specialist_backend/runs.py`: stores snapshot, ordered context and numbered events in process memory; `iter_sse_events` replays by numeric event ID and closes on `succeeded`/`failed`.
- `apps/backend/src/insight_specialist_backend/question_clarification_runs.py`: starts daemon threads. It marks the clarification-only result `succeeded`, then answer submission changes it back to `running` for interpretation.
- `apps/desktop/src/components/insight-specialist-app/insight-specialist-app.ts`: keeps run, snapshot, answers, events, selected filename and workflow step only in Lit component state. SSE starts at zero; no run locator or last processed event ID is persisted. Reload loses all of this UI state.
- `apps/desktop/src/preferences/notification-preferences.ts`: demonstrates localStorage is already used for a user preference, but not as run storage.
- `docs/authoritative/architecture/desktop-shell.md` and `docs/authoritative/backend/local-backend.md`: Tauri finds or starts a loopback sidecar, then kills only the child it started when the desktop exits. Thus just adding SQLite to the backend would preserve completed data but would not let a model call continue when the desktop closes.
- Existing deterministic tests cover in-memory store/event behavior, API URL resolution, and the question-run UI, but no process-restart/recovery contract.

The data profile (not raw CSV text) and question are sent in the run input and therefore should be part of the durable backend record. The selected filename is currently only frontend state. Clarification answers and model results already enter the context/result structures.

## Ownership options

| Option | Benefits | Problems | Decision |
| --- | --- | --- | --- |
| **FastAPI-owned SQLite run store and execution** | One authority for snapshots, answers, results, context and SSE; can make state/event writes atomic; works for browser and Tauri; existing `RunStore` seam is straightforward to preserve behind a store protocol. | Requires a local DB path, schema/versioning, retention/privacy decisions, and a sidecar lifetime that outlives the UI. SQLite alone cannot resume a request interrupted by a backend/OS crash. | **Recommend.** Backend owns durable state and workers. Add a small Tauri lifecycle change so an app-window/app restart does not stop a healthy sidecar with active runs. |
| **Lit frontend owns run state (localStorage/IndexedDB)** | Small backend change; frontend can remember an ID and selected file name. | Cannot keep a backend thread alive; duplicates authoritative data already held by FastAPI; browser storage is not available to FastAPI for atomic run/event writes; event history, multi-window access, and recovery become fragile; IndexedDB is not shared with Tauri native code. | Reject as canonical storage. Use only for a versioned locator, event cursor, and display-only metadata. |
| **Tauri/Rust owns SQLite and run lifecycle** | Native app-data path is convenient; a shell service could own a long-lived process. | Moves product workflow state across the shell boundary and requires Rust to become an API/storage authority, contrary to `desktop-shell.md`; browser mode then needs a separate implementation. | Reject for this slice. Tauri may supply an app-data directory and manage sidecar lifetime, but not own workflow records. |

## Recommended boundary and persistence

1. **FastAPI remains the sole source of truth.** Introduce a `RunStore` interface used by `QuestionClarificationRunService` and endpoints. Keep `InMemoryRunStore` for fast isolated unit tests; production/local desktop configuration uses `SQLiteRunStore`.
2. **SQLite location:** Tauri passes the platform app-data directory to the backend (e.g. `INSIGHT_SPECIALIST_DATA_DIR`), never a repository-relative/current-working-directory path. Browser development can set the same variable or use a documented per-user local default. Create the directory with user-only permissions where supported. Use SQLite foreign keys, WAL, busy timeout, and transactional writes; store structured JSON in text columns, not Python pickle.
3. **Schema:** versioned migration table; `runs` (UUID, kind, status, timestamps, input JSON, result JSON, stable error code/message, active stage, optional parent/request key); `run_events` (run UUID, monotonically increasing per-run integer sequence, timestamp, type, payload JSON; unique `(run_id, id)`); `run_context` (run UUID, monotonic sequence, step, actor, entry type, timestamp, content JSON). Enforce foreign keys and unique keys. A state transition and its corresponding event are committed in one transaction. Persist answer/context/result changes atomically too.
4. **Data minimization:** persist exactly the existing request/profile, clarification answers, workflow context and output needed to reconstruct this local run. Do not persist uploaded CSV text or LLM credentials. Store the filename as optional, non-authoritative client display metadata only. Define an explicit local retention/delete policy before shipping; until decided, do not silently prune runs. Provide a documented local DB backup/export procedure using SQLite's backup API (not copying just the main file while WAL is active).
5. **Sidecar lifetime:** on normal Tauri window/app close, do not terminate a sidecar with active runs. Launch/retain it so it can be rediscovered through the existing loopback health check on the next desktop start. Add bounded cleanup for an idle backend (or explicit user shutdown) and ensure that only the app-managed local sidecar is eligible for cleanup; never kill an externally configured/backend-managed service. The lifecycle must be tested on each supported OS because detached-child behavior differs. If the backend itself exits, do not pretend an in-flight model request continued: apply startup recovery below. Do not bind the unauthenticated sidecar beyond loopback.

## IDs and API contract

- Keep the backend-generated opaque UUID run ID (the current `uuid.uuid4().hex` format is sufficient); IDs are stable across restarts and never reused. The ID is not a credential or authorization token.
- Add client-generated UUID `Idempotency-Key` to run creation. Persist the pending key before sending the request. The backend stores it with the run under a unique constraint and returns the existing run for an identical retry; same key with a different normalized payload returns `409`. This closes the response-lost/reload duplicate-run gap. Never derive IDs from question/profile text.
- Keep `run_url` and `events_url` relative URLs. A reconnect re-resolves the backend base through the existing browser/Tauri mechanism rather than persisting an origin/port. Add `latest_event_id` to snapshots (the highest durable event sequence, zero only if there are no events) and a `GET /runs` recent-run listing for recovery if frontend locator storage is unavailable. Limit listing to this local user's store and cap/paginate results; don't add multi-user semantics.
- SSE `id:` remains the event sequence. Resume using `Last-Event-ID` (takes precedence over `?after=`), validate it as a non-negative integer not beyond the current high-water mark, and replay strictly greater IDs. Do not infer a cursor from the number of UI events because retries/reloads may create duplicates. Keep event processing idempotent by ignoring already-applied IDs. Update the current CORS allow-header list to include `idempotency-key`; retain the existing restricted local-origin policy.
- Preserve existing snapshot and result shape where possible. Add stable `error_code` and `error` fields; retain useful human-readable messages. Use `404` for unknown/expired IDs, `409` for invalid state or idempotency conflict, `400` for invalid answers/cursors, and a clearly explained retryable `503` when storage is unavailable. Do not expose local DB paths, credentials, or tracebacks in API errors.

## State machine and recovery policy

Replace the current ambiguous use of `succeeded` for a clarification result that is still awaiting user input. Persist and expose these states:

```text
queued -> running -> awaiting_clarification -> running -> succeeded
   |         |                  |                 |
   +---------+------------------+-----------------+-> failed
   +-----------------------------------------------> interrupted (recovery only)
```

- `queued` means accepted and not yet dispatched. Startup may safely dispatch a durable queued run once.
- `running` means a worker has begun; persist the stage and attempt/worker marker before the external call.
- `awaiting_clarification` is a stable, reconnectable nonterminal user-wait state. The clarification result is available here. Answer submission is allowed only from this state and atomically claims the transition back to `running`; reject duplicate/concurrent submissions with `409` (or return the same accepted result for a repeated matching answer submission using an answer request idempotency key).
- `succeeded` means the whole current question workflow, including interpretation when required, is complete. If no blocking clarification is needed, the clarification result can progress directly to `succeeded` according to an explicit product rule; do not signal terminal success before that rule is met.
- `failed` is a known workflow failure. Preserve stage and safe error details in the snapshot and events; terminal failures are visible after reconnect.
- On backend startup, recover persisted `queued` records for execution; convert records left `running` to `interrupted` with a `backend_restarted_during_run` error/event. Do not automatically repeat an uncertain model request. Interrupted runs remain readable and can be explicitly restarted as a new run (new UUID, optional `parent_run_id`) after the user reviews the duplicate-call warning. A normal desktop restart with the sidecar still running does not invoke this recovery path, so the original run remains genuinely in progress.

Events should make the state boundary explicit: add `run_awaiting_clarification`, `run_interrupted`, and use `run_succeeded` only for the terminal complete workflow. Treat `interrupted` as terminal for SSE closure, like `failed` and `succeeded`. Add the new event to the Lit client's recognized run-event types. Keep stage/model progress events and context append-only. Make every transition/event sequence monotonic and durable. A later attempt is a new run rather than mutating old event history.

## Frontend reconnection and UI restoration

1. Keep a versioned frontend locator (e.g. `insight-specialist.run-locator.v1`) containing `run_id`, the create idempotency key while pending, `last_processed_event_id`, and optional selected filename. This is navigation metadata, not a copy of result/context. Catch storage denial/quota/parse errors and fall back to `GET /runs`; never fail run execution because localStorage is unavailable.
2. On app connect: resolve backend; load locator; fetch authoritative snapshot; reconcile form/question/profile, result, accepted answers, stage and status from that snapshot; then open SSE from the stored cursor. If no usable locator, offer recent local runs from `GET /runs` rather than silently creating a new run. Keep the new-run form available.
3. Save the event cursor only after applying the event to UI state. Deduplicate by event ID and use the snapshot as authoritative if an SSE event is missed. On EventSource failure, keep the run ID and show reconnecting/retry UI; do not convert a transport disconnect into a run failure. Poll `GET /runs/{id}` with bounded backoff as a fallback for transient SSE failure, then reconnect from the last committed cursor.
4. Derive current screen from snapshot status/result/context, not from an assumed in-memory sequence. Restore the original question and summarized profile from `snapshot.input`, filename from locator if present, answers from accepted answers/context, and interpretation from result. Never restore/claim availability of raw CSV bytes: the current run does not need them once the profile has been submitted.
5. When backend is unreachable, retain the locator and show a recoverable backend-unavailable message. Do not clear old run state on startup errors. On `404`, explain that the selected run is no longer present and offer the recent-run list/new run. On a corrupt/invalid locator, discard only that locator and report that run history can be browsed.

## Migration, rollout and rollback

1. Land the store interface and SQLite schema/migrations with unit tests; existing in-memory tests remain supported. There is no live-run migration from the current implementation: its data dies with its process. The first SQLite-backed launch creates an empty DB; any already-running in-memory run at upgrade is necessarily unavailable after backend restart and should be described as such.
2. Deploy behind a local configuration switch (`memory` versus `sqlite`) and expose the selected storage mode only in diagnostics, not secrets. SQLite is the Tauri default after verification; test/development can explicitly use memory. On migration/schema failure, fail startup clearly rather than silently falling back to an empty in-memory store and losing apparent history.
3. Roll out UI locator/reconnect only after durable snapshots and stable event cursors work. Then change Tauri exit/sidecar lifecycle and test discovery/reuse, idle shutdown and platform cleanup. Keep existing create/get/SSE/answers endpoints backward-compatible during transition; add response fields and state/events without removing prior event types until clients/tests migrate.
4. Rollback: stop new app launches, preserve and back up the SQLite DB, switch new instances to the prior in-memory mode only if the operator accepts that history becomes unavailable to that instance; never delete/overwrite the DB. Restore the previous Tauri sidecar lifecycle independently if it causes orphan processes. Keep a schema downgrade unnecessary: old binaries should not be pointed at a newer DB unless they explicitly support that schema version; back up and use a versioned DB copy for rollback. Report to users that in-memory rollback cannot recover/continue persisted work.

## Test plan

### Backend unit and storage tests (no model server)

- Store contract parity for memory and temporary-file SQLite: create/get, stable UUID, atomic transition+event, ordered context, result/error persistence, monotonic event IDs, filtering after cursor, terminal/wait behavior, concurrent read/write, and reopening the DB in a new store instance.
- SQLite constraints and migration tests: fresh DB, each supported prior schema migration, unique request key, same key/same payload returns one run, mismatched payload conflicts, transaction rollback on write failure, WAL reopen, and unavailable/corrupt/locked DB produces explicit startup/API errors.
- State machine tests for legal and illegal transitions; clarification run reaches `awaiting_clarification`, answer submission claims it once, accepted answers persist, interpretation ends in `succeeded`; malformed/model errors become `failed`; concurrent duplicate answer posts do not start two interpretation workers.
- Recovery tests: queued runs are dispatched exactly once; running record on process reopen becomes `interrupted` with one durable event and remains readable; terminal records/results/events/context survive reopen unchanged. Verify no automatic second model call after recovery.
- SSE tests for replay after cursor, `Last-Event-ID` precedence/validation, no duplicate/lost event at snapshot-to-stream race, terminal closure, heartbeat, and unknown run `404`.

### HTTP integration tests (fake model, no credentials)

Run FastAPI against a temporary DB. Create, close/reopen app/store as a distinct backend process, fetch the same ID and result, resume SSE, submit answers once, and verify `409`/`400`/`404`/`503` contracts. Exercise idempotent create after simulating a lost response. Assert loopback CORS constraints and that errors/settings do not disclose secrets or filesystem paths. No live LLM integration is needed for this feature.

### Frontend and desktop tests (mock backend)

- API unit tests: idempotency header, relative URL construction, typed statuses/cursor/snapshot fields, HTTP error categories, and Tauri versus Vite base URL.
- Lit component tests: startup locator restore, completed snapshot restore without SSE, awaiting-clarification restore with answers, active-run reconnect/cursor replay/dedup, backend unavailable and retry without clearing locator, corrupt/unavailable localStorage fallback to recent runs, unknown run handling, and starting a new run without corrupting the previous locator.
- Browser UI test: run in mock backend, reload the page while running and after completion, verify same run ID/state/results and no second create request. Simulate missed SSE events and EventSource failure then poll/reconnect.
- Tauri shell test/manual cross-platform smoke: close/reopen the desktop while a delayed fake run is active; verify the same local sidecar stays healthy and run finishes; relaunch and reconnect to result. Verify idle cleanup, app-managed versus externally managed backend ownership, and no process leak after configured cleanup. Do not use a real LLM or remote endpoint.

## Verification commands for implementation

Follow `docs/authoritative/engineering/verification/backend.md`, `desktop-frontend.md`, and `tauri-shell.md`. At minimum run backend unit tests and temporary-DB HTTP integration tests; frontend unit/build and mocked UI tests; Rust check/tests if lifecycle wiring changes; desktop WebDriver where available. Keep live model tests opt-in and unnecessary for this work. Record missing runtimes/drivers and run narrower available deterministic tests.

## Acceptance criteria

- A run ID plus backend store survives backend process restart for completed, awaiting-input, and interrupted records.
- Closing/reopening the desktop alone does not cancel a run: on relaunch the app finds the same sidecar, snapshot, and SSE cursor, and reconnects without duplicate creation.
- Completed results and clarification answers reconstruct the correct Lit step and remain visible without re-uploading CSV or calling the model again.
- Backend/OS crashes during an external call are represented honestly as interrupted, never silently retried; explicit restart creates a new linked run.
- Browser/Vite mode continues to work with mocked backend and local storage degradation; no remote service/cloud credential is introduced.
