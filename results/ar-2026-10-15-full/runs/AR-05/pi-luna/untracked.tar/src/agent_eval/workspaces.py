"""Workspace provisioning and lifecycle for evaluation runs."""
from __future__ import annotations

import hashlib
import subprocess
import tarfile
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


def prepare_workspace(repos: dict[str, dict], task: dict, destination: Path) -> dict[str, str]:
    """Export the task's pinned commits into a read-only workspace."""
    destination.mkdir(parents=True, exist_ok=False)
    commits: dict[str, str] = {}
    for name in task["repos"]:
        info = repos[name]
        source = Path(info["path"])
        target = destination / name
        target.mkdir(parents=True)
        proc = subprocess.Popen(["git", "-C", str(source), "archive", "--format=tar", info["commit"]],
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        assert proc.stdout is not None
        links: list[tuple[Path, str]] = []
        with tarfile.open(fileobj=proc.stdout, mode="r|") as tar:
            for member in tar:
                member_path = (target / member.name).resolve()
                if not member_path.is_relative_to(target.resolve()):
                    proc.kill()
                    raise ValueError("Unsafe path in git archive")
                if member.issym():
                    if Path(member.linkname).is_absolute() or not (member_path.parent / member.linkname).resolve().is_relative_to(target.resolve()):
                        proc.kill()
                        raise ValueError("Unsafe symlink in git archive")
                    links.append((member_path, member.linkname))
                    continue
                if member.islnk():
                    proc.kill()
                    raise ValueError("Unsupported hard link in git archive")
                tar.extract(member, target, filter="data")
        stderr = proc.stderr.read().decode(errors="replace") if proc.stderr else ""
        if proc.wait() != 0:
            raise RuntimeError(f"git archive failed: {stderr[:500]}")
        proc.stdout.close()
        if proc.stderr:
            proc.stderr.close()
        for link_path, link_target in links:
            link_path.symlink_to(link_target)
        commits[name] = info["commit"]
    for path in destination.rglob("*"):
        if path.is_file():
            path.chmod(0o444)
        elif path.is_dir():
            path.chmod(0o555)
    destination.chmod(0o555)
    return commits


def tree_digest(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        digest.update(str(path.relative_to(root)).encode())
        if path.is_file():
            digest.update(path.read_bytes())
    return digest.hexdigest()


@contextmanager
def snapshot_workspace(repos: dict[str, dict], task: dict) -> Iterator[Path]:
    """Provision a pinned, read-only export and remove it when the run ends."""
    with tempfile.TemporaryDirectory(prefix="agent-eval-") as temporary:
        workspace = Path(temporary) / "workspace"
        prepare_workspace(repos, task, workspace)
        yield workspace
