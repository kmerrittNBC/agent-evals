"""Workspace provisioning and lifecycle for agent runs.

Harness execution only needs a directory to use as its working tree. Providers
own how that directory is created and how its resources are released.
"""
from __future__ import annotations

import hashlib
import subprocess
import tarfile
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import ContextManager, Iterator, Protocol


class Workspace(Protocol):
    """A provisioned workspace exposed to a harness run."""

    path: Path
    snapshot_digest_before: str

    def verify_integrity(self) -> tuple[bool, str]:
        """Return whether the workspace passed its policy and its final digest."""
        ...


class WorkspaceProvider(Protocol):
    """Creates a workspace and owns its cleanup for the yielded lifetime."""

    def open(self, repos: dict[str, dict], task: dict) -> ContextManager[Workspace]: ...


def prepare_workspace(repos: dict[str, dict], task: dict, destination: Path) -> dict[str, str]:
    """Export pinned commits into a read-only snapshot directory."""
    destination.mkdir(parents=True, exist_ok=False)
    commits: dict[str, str] = {}
    for name in task["repos"]:
        info = repos[name]
        source = Path(info["path"])
        target = destination / name
        target.mkdir(parents=True)
        proc = subprocess.Popen(["git", "-C", str(source), "archive", "--format=tar", info["commit"]],
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        assert proc.stdout is not None
        links: list[tuple[Path, str]] = []
        with tarfile.open(fileobj=proc.stdout, mode="r|") as tar:
            for member in tar:
                member_path = (target / member.name).resolve()
                if not member_path.is_relative_to(target.resolve()):
                    proc.kill()
                    raise ValueError("Unsafe path in git archive")
                if member.issym():
                    if Path(member.linkname).is_absolute() or not (member_path.parent / member.linkname).resolve().is_relative_to(target.resolve()):
                        proc.kill()
                        raise ValueError("Unsafe symlink in git archive")
                    links.append((member_path, member.linkname))
                    continue
                if member.islnk():
                    proc.kill()
                    raise ValueError("Unsupported hard link in git archive")
                tar.extract(member, target, filter="data")
        stderr = proc.stderr.read().decode(errors="replace") if proc.stderr else ""
        if proc.wait() != 0:
            raise RuntimeError(f"git archive failed: {stderr[:500]}")
        proc.stdout.close()
        if proc.stderr:
            proc.stderr.close()
        for link_path, link_target in links:
            link_path.symlink_to(link_target)
        commits[name] = info["commit"]
    for path in destination.rglob("*"):
        if path.is_file():
            path.chmod(0o444)
        elif path.is_dir():
            path.chmod(0o555)
    destination.chmod(0o555)
    return commits


def tree_digest(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        digest.update(str(path.relative_to(root)).encode())
        if path.is_file():
            digest.update(path.read_bytes())
    return digest.hexdigest()


class ArchiveWorkspaceProvider:
    """Temporary, immutable exports of pinned commits.

    A future Git-worktree provider can implement the same context-manager seam
    while owning worktree registration/removal and selecting its own integrity
    policy for a writable tree.
    """

    @contextmanager
    def open(self, repos: dict[str, dict], task: dict) -> Iterator[Workspace]:
        temporary = tempfile.TemporaryDirectory(prefix="agent-eval-")
        try:
            path = Path(temporary.name) / "workspace"
            prepare_workspace(repos, task, path)
            workspace = _ArchiveWorkspace(path, tree_digest(path))
            yield workspace
        finally:
            temporary.cleanup()


class _ArchiveWorkspace:
    def __init__(self, path: Path, snapshot_digest_before: str):
        self.path = path
        self.snapshot_digest_before = snapshot_digest_before

    def verify_integrity(self) -> tuple[bool, str]:
        after = tree_digest(self.path)
        return after == self.snapshot_digest_before, after
