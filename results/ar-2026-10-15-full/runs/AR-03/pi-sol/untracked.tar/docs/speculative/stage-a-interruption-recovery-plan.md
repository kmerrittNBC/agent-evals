# Proposal: recover an interrupted Stage A reservation without replay

Status: implementation plan only; **not** an operator authorization. The current
[continuous-cohort runbook](../runbooks/stage-a-continuous-cohort.md#stop-and-resume)
still stops on an uncertain reservation. Do not apply this procedure to a live
ledger until its implementation, admission and owner review are complete.

## Existing boundary

- The `archive-stage-a-cohort/1` freeze is published from the exact owner-approved
  candidate, admission and host digest; publication writes the gate before the
  configured freeze and has a checksum-checked, no-overwrite recovery for that
  gap. The ledger is initialized once from that freeze. `verify_plan`,
  `verify_configured_freeze` and `load_state` reject a changed approval,
  configuration, plan or manifest digest. The 23 ordered prepared-archive tasks,
  seven standard arms, one attempt per slot and 161 schedule/slot-plan entries
  remain fixed; no first-block stop is inserted. See the [publication and init
  steps](../runbooks/stage-a-continuous-cohort.md#10-publish-the-approved-freeze),
  [scheduler contract](../runbooks/stage-aware-scheduler.md#frozen-inputs) and
  [numerical reconciliation](../runbooks/seven-arm-stage-a-freeze.md).
- `stage_a_launcher.run_block` rehearses before reservation; `dispatch_next`
  then persists an `in_flight` slot and account reservation, *before* creating
  `<lease>/intent.json`. `execute_attempt` runs native work, confirms cleanup,
  verifies independently, normalizes a result and returns a completion;
  launcher writes `completion.json`, then calls `record_attempt` under the
  ledger lock. An exception writes `interrupted.json` but does not release the
  reservation. A kill may precede either file. A stopped unit with no
  reservation may be restarted; with a reservation `run_block` refuses to run.
- `run_cohort_step` validates chained clean-block progress, catches up a block
  settled in the ledger but missing its progress record, and never advances
  over an active lease. The offline cohort audit validates the whole checkpoint,
  progress, artifacts and research evidence; the execution seal requires that
  exact passing audit, quiescent resources and one row per scheduled slot.
  `_attempt_row` currently requires a real completion, normalized result and
  lifecycle for **every attempted terminal slot**. A missing result cannot be
  passed off as `unstarted`: that disposition requires no attempt. The v2
  task-outcome seal is emitted only if all scheduled slots have task records;
  the outer execution seal accounts for missing records. See
  `stage_a_first_block.py`, `stage_a_cohort_audit.py`, `stage_a_seal.py`.
- [Scoped Inspect recovery](../runbooks/inspect-recovery-and-shakedown.md#operator-recovery)
  proves abandoned ownership and cleans only linked resources; it does not
  decide an outcome or refund charges. The narrow [prelaunch Claude
  recovery](../runbooks/stage-a-first-block-gate.md) requires proof that *no*
  native execution began and is not a general host-interruption precedent.

## Decision and state machine

Choose **evidence-based terminal reconciliation** for a genuinely interrupted
native attempt, not replay or process continuation. Recovery is an explicit
owner-authorized action on the *existing lease* after the unit is stopped. No
new dispatch, attempt number, native call, grader run or provider request.

| Observed state after a stop | Action | Next state |
| --- | --- | --- |
| No lease, pending slot | Fix pre-reservation cause and restart same unit; after window end reconcile pending as unstarted. | pending → in_flight on ordinary dispatch, or pending → unstarted after end |
| No lease, block settled but progress missing | Existing checked-ledger catch-up. | terminal slots unchanged; append progress |
| Active lease, `completion.json` already durable but ledger finish missing | Verify intent, result, evidence, cleanup, account journal and completion exactly as the audit would; under locks finish that same lease with its original typed disposition/digest, then append progress if block settled. Do **not** execute worker. | in_flight → terminal |
| Active lease, no valid completion, native possibly started | Prove owner abandoned and all native/Inspect/verifier/research resources quiescent; retain partial artifacts and charged usage. With explicit owner decision and recovery attestation, finish the same lease as `infrastructure_failed` with a *new nonretryable* `host_interrupted` error code and an explicit missing-result recovery receipt. | in_flight → terminal (no task score) |
| Active lease, ownership or accounting uncertain, unexpected/contradictory evidence, or cleanup fails | Stop. No ledger mutation or block advancement; escalate to owner, possibly retire the *entire* attempt under the existing runbook. | in_flight unchanged |

Replay would risk a second provider charge or different patch under the same
frozen slot; a second attempt violates the one-attempt limit. Continuing a
partly streamed native process after reboot cannot prove original sandbox,
credentials, time budget or isolation and must not be implemented. Finishing
from already sealed completion evidence is **recording recovery**, not native
resume. The earlier Claude no-native-work exception remains separate and
must not silently become permission to retry an uncertain native call. An
interruption is infrastructure missing, never an incorrect patch, unsupported
task, zero score or an unstarted slot. Other six arms and remaining task blocks
stay scheduled in their original order.

## Implementation slices (test first at each seam)

1. Add a *read-only* recovery inspection command on the admitted checkout,
   holding the launcher lock then the scheduler lock in the existing order.
   Authenticate published freeze/approval/plan/slot plan, configuration, host
   profile, target admission, ledger event history, exact lease/slot/attempt
   identity and progress prefix. Inventory `intent`, `interrupted`, `completion`,
   native/verification artifacts and task-input store without following links.
   Classify only the states above; do not infer "never started" from a missing
   file. Record a digest of the pre-recovery scheduler checkpoint. Reject a
   second running launcher, changed execution commit or stale admission rather
   than rebind to a new freeze. Keep diagnostics credential-free.
2. Implement a bounded, scoped quiescence check using Inspect ownership
   receipts, Docker endpoint/member labels, owner PID/start/boot identity and
   `recover_abandoned_trials` where applicable; confirm no surviving native
   process, verifier, credential consumer or research service and verify the
   image/store state. Re-export volatile leases only for *future* slots. Never
   perform a global Docker sweep. Reconcile the conserved research journal's
   per-trial charges and active reservations against the original trial, without
   deleting/refunding rows; the existing live-remainder gate still applies to
   all unsettled future slots. If receipts or accounting cannot prove safety,
   leave the lease active.
3. Introduce a versioned, immutable recovery attestation under the canonical
   artifact root, binding freeze and outcome-slot-plan digests, configuration,
   admitted execution commit, checkpoint digest, lease/attempt/trial, original
   artifact inventory, cleanup receipts, charged-use snapshot, timestamps,
   owner identity/decision and reason. Persist it no-replace and hash it in a
   distinct recovery completion. Recheck all inputs while holding the same
   locks immediately before `record_attempt`; if a crash occurs before the
   ledger update, rerunning must verify and reuse the same attestation, not
   manufacture a second one. If a crash occurs after the ledger update, verify
   terminal digest and treat as done. An existing ordinary completion must take
   the recording-only branch and never be overwritten.
4. Add a narrowly gated scheduler transition via existing `record_attempt` for
   the same lease, with `infrastructure_failed` / `host_interrupted`, no retry
   eligibility and full frozen account consumption. Do not broaden `reconcile_pending`
   (which forbids in-flight work), reset a reservation, edit `limits`, change
   schedule/order, or permit a second dispatch. Validate the new code against
   the frozen retry policy: if policy/schema interpretation needs changing,
   implement as a backward-compatible *evidence interpretation* for this
   terminal recovery, not a mutation of the approved freeze. Historical
   ledgers remain validated with their recorded implementation.
5. Teach the cohort audit and outer execution seal a distinct **attempted,
   interrupted, no-result** row, requiring the attestation and recovery
   completion hash to equal scheduler terminal evidence; validate original
   artifacts/inventory, account charges, quiescence and absence of a scored
   result. Count it as attempted and infrastructure missing, not valid or
   unstarted. Do not synthesize `result.json`/`lifecycle.json` or a v2 task
   outcome. The outer seal includes all 161 slots and may have a null v2
   task-outcome seal (as with unstarted slots). Downstream Stage B admission
   must not treat this as a solved or failed capability task; require explicit
   owner disposition for any incomplete comparative screen. Preserve all seven
   arm IDs and planned slots in every report.
6. Update the continuous-cohort stop/resume and audit/seal runbooks *after*
   validation: owner confirmation, exact command/expected receipt, failure
   cases, research and resource evidence retention. Add a dry-run inspection
   first and prohibit automatic invocation by the systemd restart loop.

## Acceptance tests and rollback

Use fixture freezes at the scheduler seam, then an archive-cohort fixture with
23 × 7 slots at the launcher/audit/seal seams. Red before green: reservation
before intent, kill during native, kill after native cleanup but before
verification, complete artifact before ledger finish, kill before/after
attestation and after ledger finish, settled block before progress. Assert no
second native call, no second lease, no refund, unchanged frozen digests and
order, correct charged-work remainder and exactly one progress record. Reject
live owner/PID reuse or unverified boot, mixed Docker labels, missing cleanup,
changed approval/slot plan/commit, symlink or altered artifact, stale checkpoint,
forged completion and missing owner decision. Test no-score seal counts and
Stage B refusal separately; test a restart of an ordinary pending slot and
finite-window reconciliation unchanged. Run focused scheduler, launcher,
Inspect recovery, numerical, cohort audit, seal and Stage B consumer tests;
reserve `make check` for final integrated acceptance.

Before rollout, keep the old fail-closed binary/runbook as the rollback path.
If any new check fails, stop the unit and retain ledger, artifacts, task-input
store, research journal and ownership receipts untouched. Before a terminal
transition one may revert code and remain stopped; after it, **never** roll the
ledger back or resume under older code that cannot interpret the new evidence.
Pin the new revision and audit/seal there, or retire the whole attempt with
owner approval, retaining all prior evidence and starting a separately
approved freeze/ledger. A code revision or new cohort is not an in-place
change to the approved 23-task, seven-arm freeze.
