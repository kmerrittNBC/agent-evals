# Stage A host-interruption recovery: implementation plan

**Status: proposed, not implemented.** Nothing here is current behavior. The
current behavior is in
[the continuous-cohort runbook](../runbooks/stage-a-continuous-cohort.md#stop-and-resume)
and [ADR-0016](../authoritative/adr/0016-screen-stage-a-on-23-reviewed-tasks.md):
an interrupted reservation stops the cohort, and the only remedy is to retire
the attempt. Planned at `b0b31dd` (2026-10-15).

## Goal and fixed constraints

After a host interruption (power loss, kernel panic, forced reboot), the
scheduler should resume the same `archive-stage-a-cohort/1` ledger, rather than
retiring a cohort of 161 slots because one slot was in flight. The following
must not change:

- **Frozen cohort.** The freeze, its digest, the 23 task IDs, the 161-slot
  schedule and outcome slot plan, the seven arms, `limits.attempts = 1` and the
  frozen `retry_policy` all stay exactly as they are. Recovery never edits the
  freeze, configuration, approval or admission, and never needs a new one.
- **No replay of a native coding attempt.** A native attempt that may have
  passed the [provider-contact boundary](../../CONTEXT.md) never runs again,
  in any directory, under any lease or attempt number.
- **Ledger.** The ledger is never reset or rewritten. No reservation is
  refunded. No second attempt is created. The ledger schema
  (`stage-scheduler-state/2`) stays the same.
- **Seven-arm comparison.** Every slot keeps exactly one disposition. No slot
  is dropped, reordered, given to another arm, or marked `unstarted` once it
  has been dispatched. The futility rule
  `resolved + capability_unknown + unstarted <= 1` is applied to all 23 slots
  of every arm, with no change.
- **Fail-closed by default.** If no recovery record has been authorized, the
  existing stop (`unreconciled active attempt; retain evidence, do not rerun`)
  is unchanged.

## Current trace: where a host interruption lands

| Step | Code | Durable effect |
| --- | --- | --- |
| Freeze and slot plan | `stage_scheduler.validate_state` (`agent_harness_evals/stage_scheduler.py:344`) | The ledger identity is the freeze digest, the slot plan, `trial_id = uuid5(freeze/trial/slot)` and `attempt_id = uuid5(trial/attempt/n)`. |
| Rehearsal (nothing reserved) | `stage_a_launcher.run_block` (`stage_a_launcher.py:294`), `stage_a_execution.rehearse` | Scratch on tmpfs only. |
| Reservation | `dispatch_next` (`stage_scheduler.py:1120`) in `locked_state` | The slot becomes `in_flight`; one reservation; a `dispatch` event; `actual_order` is assigned. The ledger is fsynced. |
| Attempt directory and intent | `stage_a_launcher.py:319-326` | `mkdir <lease>/` (the parent is not fsynced), then `intent.json` (fsynced). |
| Native preparation | `stage_a_native._run_native` (`stage_a_native.py:108-269`) | `native/` and the observer capture directory. The disposable trial ID and research scope exist only in memory and on tmpfs. |
| **Provider-contact boundary** | `inspect_execution.evaluate_task` (`inspect_execution.py:112-130`) | First `native/inspect-events.jsonl` (O_EXCL), then `native/ownership.json`. The ownership file is fsynced and its owner labels carry the PID, process start ID and **boot ID**. Both are written **before** Inspect creates any container. |
| Native end | `stage_a_native.py:318-331` | `native.json`, `inspect.json`, `transport.json`, `research.json`. These are written only at the end or on an exception. |
| Verification | `stage_a_archive_verifier` | `verification/`, plus task-input-store trees for the composed workspace. |
| Completion | `stage_a_launcher.py:335` | `completion.json` (fsynced). |
| Record | `record_attempt` (`stage_scheduler.py:1402`) | The slot becomes `terminal`, the reservation is closed, and consumption is charged in full. |
| Progress | `_record_block` (`stage_a_launcher.py:384`) | `cohort-progress/block-NNNN.json`, chained. If the process crashed first, this is caught up on the next invocation. |
| Audit | `stage_a_cohort_audit.build_cohort_audit` | `_attempt_row` (`stage_a_first_block.py:173`) on every slot; `verify_store`; renewals; progress. |
| Seal | `stage_a_seal.build_stage_a_execution_seal` | `_attempt_row` again; the v2 outcome seal is built only if **every** slot has a record. |

After a reboot, the next invocation stops at `stage_a_launcher.py:270`
whenever `state['reservations']` is non-empty, wherever the interruption
happened. Today's recovery runbook then sends the owner to *Retire a stopped
attempt*. That procedure abandons the ledger and requires a new freeze, and
"its stopped slot runs again as a fresh slot of the next attempt's freeze". In
practice, then, today's only path re-runs the interrupted native attempt in a
new cohort, and discards every settled slot along with it.

### Gaps found while tracing

- **G1. Every reservation looks the same.** The launcher cannot tell a
  reservation that never reached the boundary from one whose agent ran for
  forty minutes.
- **G2. A completed attempt can be left unrecorded.** A crash between
  `completion.json` and `record_attempt` leaves complete, verified evidence
  that the launcher refuses to finish recording. The credential-free
  [scheduler preflight](../runbooks/scheduler-to-seal-preflight.md) already
  reuses saved executor output in this situation; the live launcher does not.
- **G3. The seal rejects a prelaunch-recovered slot. This is a current
  defect, reproduced.**
  - `seal_stage_a` calls `_attempt_row(freeze, slot, root, configuration_digest)`
    without `execution_commit` (`stage_a_seal.py:220`), and
    `_prelaunch_recovery` requires it.
  - Running `build_stage_a_execution_seal` on the existing
    `recovered_checkpoint` test fixture, with the remaining slots marked
    unstarted, raises `prelaunch recovery differs from the frozen execution`.
  - The seal's outcome roots also use `artifact_root / lease_id`
    (`stage_a_seal.py:251`), not the resumed directory.
  - Every resume design below depends on fixing this first.
- **G4. Nothing durable links an attempt to its research trial before the
  boundary.** The disposable trial ID and research scope are written only in
  `native.json` at the end, or on tmpfs, which a reboot erases. A recovery
  therefore cannot attribute a stale `provider-gate` lease or a
  `trial-work:<trial>` row exactly.
- **G5. Partial task-input trees fail the audit.** A verifier interrupted
  while composing its workspace leaves trees that no manifest covers.
  `verify_store` then fails
  (`task_input_store.py:251`, the store inventory must equal the trees the
  manifests cover). The first-block runbook forbids moving trees by hand.
- **G6. The attempt directory entry may not survive.** `mkdir <lease>/` is
  not followed by an fsync of the artifact root, so after a power loss the
  directory entry can be lost even though the ledger holds the reservation.

## Interruption classes

A reviewed classifier assigns each in-flight lease to one class. It reads only
retained evidence (file names, sizes, hashes), the ledger and the research
database, and it never mutates anything:

| Class | Witness on disk | Provider or research contact possible? |
| --- | --- | --- |
| **C0: reserved, not launched** | The ledger holds the reservation; `<lease>/` is absent or has no `intent.json`. | No |
| **C1: launched, before the boundary** | `intent.json` exists. There is no `native/inspect-events.jsonl`, no `native/ownership.json` and no `completion.json`. The attributed `trial-work` row is absent or has zero usage. | No. Inspect never started, so no container existed. |
| **C2: past the boundary, unsettled** | `inspect-events.jsonl` or `ownership.json` exists, with no valid `completion.json`. | Yes. The agent may have worked. |
| **C3: completed, not recorded** | `completion.json` exists and validates against `result.json` and the lease (the `_attempt_row` checks). | Already settled in evidence. |

Anything else is **unclassifiable**: unknown files, a hash mismatch, research
usage in C0 or C1, a trial that cannot be attributed, or the same boot. An
unclassifiable lease keeps today's fail-closed stop.

## Options compared

| | Replay (new native run) | Resume under the same reservation | Terminal failure (`infrastructure_failed`) |
| --- | --- | --- | --- |
| C0 / C1 | Rejected: a second attempt violates `attempts = 1` and the retry policy. | **Recommended.** No native work exists to replay. Lineage, reservation and charges are unchanged. This generalizes the existing prelaunch recovery. | Allowed (owner's choice), but it wastes a valid slot. |
| C2 | **Rejected.** The agent already saw the task, the provider and research usage were charged, and an interrupted arm would get an extra draw (selection bias). ADR-0016 and the v5 contract forbid it. | Rejected: there is no way to continue a lost process tree. | **Recommended** and the only choice. Error code `host_interrupted`; the outcome is `capability_unknown`. |
| C3 | Not applicable | **Recommended:** record the retained completion without re-execution. | Not applicable: the evidence already decides it. |

Also rejected:

- **Marking the slot `unstarted`.** It was dispatched, and `actual_order` is
  set. `reconcile_pending` is allowed only after the window ends and only for
  pending slots. An unstarted row would also cancel the v2 outcome seal
  (`len(records) == len(rows)`).
- **Automatic recovery without an owner record.** It would change ADR-0016's
  "uncertain or active attempt is never replayed" without a decision.
- **Regrading a C2 attempt whose native run finished.** This means running
  the grader after the interruption on the retained candidate. It is
  provider-free and attractive, but the
  [preserved-image diagnostic](../../CONTEXT.md) definition makes such a grade
  retrospective, not comparative. It needs its own ADR, so it is out of scope
  here, and those attempts take the terminal path.
- **Treating a same-boot process death as a host interruption.** Attempt 6
  showed that orphaned agent processes can outlive their server. Only a reboot
  proves that every process tree is gone. The first slice therefore requires a
  different boot ID; a same-boot variant (watchdog, OOM) needs proof that the
  owner's PID and start ID are dead, plus container quiescence, and is a
  follow-up.

## State transitions

The scheduler ledger is unchanged. Recovery is expressed through immutable
evidence records and the existing `record_attempt`:

```
in_flight (reservation R, attempt 1)
 ├─ C0/C1 ──owner: resume──► recovery record {decision: resume_before_contact, n}
 │                           ─► run_block: rehearse ─► intent in <lease>-host-resume-r<n>/
 │                           ─► execute (same lease) ─► completion ─► record_attempt ─► terminal
 ├─ C0/C1 ──owner: terminal─┐
 ├─ C2 ─────owner: terminal─┴► recovery record {decision: terminal}
 │                           ─► <lease>-host-terminal-r1/{completion,result,lifecycle,verifier}.json
 │                           ─► record_attempt(infrastructure_failed, host_interrupted) ─► terminal
 └─ C3 ─────owner: record───► recovery record {decision: record_completion}
                             ─► record_attempt(outcome from completion.json) ─► terminal
```

- **Allowed record transitions.** Resume can be superseded by terminal, but
  only before the resumed intent exists. Terminal is final. Resume is limited
  to `r1` and `r2`: every earlier resume directory must itself classify as C1,
  and beyond `r2` only terminal is offered.
- **Ordering in the terminal path.** The record and evidence are written and
  fsynced first, then `record_attempt` runs. If a crash falls between the two,
  the next run reclassifies the lease as C3 against the terminal evidence
  directory.
- **Ordering in the resume path.** `run_block` accepts exactly one reservation
  only when a valid unconsumed resume record names it, its slot is in the
  current block, and it is the sole `in_flight` slot. Instead of
  `dispatch_next`, it runs the slot's rehearsal, then writes the new intent,
  then calls `execute`. `execute`'s directory check (`stage_a_execution.py:276`,
  `output.name == lease_id`) accepts the recorded resume directory.
- **Progress.** `_record_block` adds `host_recovery_digests`, an additive key
  in `stage-a-cohort-progress/1` in the same way as `renewal_digests`, so the
  chain binds every recovery.

## Trust checks (all before any write)

1. **Inputs.**
   - The freeze, configuration, approval, admission directory, host profile,
     trusted digest, ledger and artifact root are the same as at launch.
   - `verify_plan`, `verify_configured_freeze`, `verify_execution_inputs`,
     `HostAdmission.check` and `StageAAdmission.check` all pass.
   - The host is unchanged: a kernel update during a reboot fails here, as
     today.
2. **The interruption is a host interruption.**
   - The current `/proc/sys/kernel/random/boot_id` differs from the boot
     recorded in the intent (new field, slice 1). For C2 it differs from the
     `owner-boot-id` label in `ownership.json`.
   - For C0, the ledger reservation's `created_at` precedes the current boot's
     start time.
   - The admitted unit has `MainPID=0` and is not active, and the launcher
     lock can be taken without blocking.
3. **Ledger.**
   - `validate_state` and `_checked_ledger` pass (progress chain intact).
   - There is exactly one reservation, its slot is in the current block, and
     all earlier blocks are settled.
4. **Evidence snapshot.**
   - The full file inventory (path, bytes, SHA-256) of `<lease>/` and every
     earlier resume directory is captured into the record before any cleanup.
   - Hashes must match the class witnesses. The secret scan runs over the
     record.
5. **Containers.**
   - Only resources labelled with this attempt's `execution_id` may exist.
   - They are removed solely through `inspect_recovery.recover_receipt` on
     that attempt's `ownership.json`, whose owner is proven dead by the boot
     ID.
   - The record binds the receipt's digest both before and after cleanup (the
     receipt rewrites itself).
   - Afterwards `TaskImageStore.environment()` passes: no containers, no
     volumes.
6. **Research.**
   - `research.sqlite` passes its integrity check and
     `validate_shared_accounting`.
   - The attributed `trial-work` row (from the slice-1 preparation record)
     must be absent or zero for C0 and C1. Otherwise the lease is reclassified
     as C2.
   - A stale `provider-gate` lease is released only for the attributed trial,
     using the same filter as `ResearchSidecar._release_provider_leases`.
     Usage is never touched.
   - The live remainder check (`remaining_research_demand`) still passes.
7. **Image store.** The state is `ready` for the current block's task, or
   `released`. `preparing` with a reservation is unclassifiable.
8. **Resume only.**
   - The time is before `cohort_window.end`.
   - The tmpfs leases have been re-exported (step 2).
   - For Claude, `verify_claude_turn` passes at the resume time, and the
     resumed intent records new `enrollment_coverage`. The audit's
     `_renewals` already reads the intent from the resumed directory.
   - Token lifetimes are rechecked by `native_credential`.
9. **Owner.**
   - The command prints the class, the evidence summary and the permitted
     decisions, and requires a typed `CONFIRM`, as enrollment renewal does.
   - It refuses any decision the class does not permit.
   - The record is written exclusively (never replaced) under
     `$artifacts/host-recoveries/recovery-<lease>-<n>.json`.

## Implementation slices (test-first, one seam each)

Every test below is written red first at the named seam. The focused check for
each slice is `uv run --locked pytest tests/<area>` for the files it touches.

0. **Seal a recovered slot.** This fixes G3 and stands alone.
   - Seam: `build_stage_a_execution_seal` and `seal_stage_a` pass
     `execution_commit` and use the evidence root that `_attempt_row`
     resolves.
   - Red: `test_seal_retains_prelaunch_recovered_slot` (`tests/test_stage_a_first_block.py`
     fixture `recovered_checkpoint`; it fails today with the message above).
1. **Durable witnesses before the boundary.** This fixes G4 and G6.
   - The intent gains `boot_id` and the launcher's PID and start ID.
   - `_run_native` writes `native/preparation.json` with the disposable trial
     ID, research scope unit and boot ID, fsynced, before `evaluate_task`.
   - The artifact root is fsynced after `mkdir`.
   - Tests:
     - `test_launch_intent_records_boot_identity`
     - `test_preparation_record_precedes_provider_contact_boundary` (ordering
       against a stub `evaluate_task`)
     - `test_rehearsal_writes_no_preparation_record_outside_scratch`
2. **Classifier (pure function, no I/O beyond reads).** This is
   `stage_a_interruption.classify`.
   - One test per class: `test_classify_reserved_unlaunched`,
     `test_classify_launched_before_boundary`, `test_classify_past_boundary`,
     `test_classify_completed_unrecorded`.
   - Negative tests: `test_classify_refuses_same_boot`,
     `test_classify_reclassifies_research_usage_before_boundary`,
     `test_classify_refuses_unknown_files`,
     `test_classify_refuses_preparing_image_with_reservation`.
3. **Recovery record tool.** This is `scripts/recover_stage_a_interruption.py`
   with `inspect` (read-only) and `record`.
   - `test_recovery_refuses_resume_past_boundary`
   - `test_recovery_requires_typed_owner_confirmation`
   - `test_recovery_record_is_never_replaced`
   - `test_resume_refused_after_cohort_window`
   - `test_resume_superseded_only_before_resumed_intent`
4. **Terminal path.**
   - `test_host_interrupted_attempt_records_infrastructure_failed`: the v2
     result is `unknown` / `infrastructure_missing`, `error_code=host_interrupted`,
     consumption equals the full demand, there is no refund, and the ledger
     validates.
   - `test_terminal_recovery_keeps_original_evidence_bytes`
   - `test_crash_between_terminal_evidence_and_record_reclassifies_as_completed`
   - Timing: `started_at` is the original intent and `finished_at` is the new
     boot's start time, an upper bound labelled as such in `lifecycle.json`.
5. **Completed, not recorded (C3).**
   - `test_retained_completion_is_recorded_without_rerunning_the_worker`
     asserts that the worker stub is never called.
6. **Resume path in `run_block`.**
   - `test_run_block_resumes_authorized_reservation_without_new_dispatch`:
     the dispatch event count is unchanged, `attempts == 1`, and the worker is
     called once, in `-host-resume-r1`.
   - `test_run_block_still_stops_on_unauthorized_reservation` (the existing
     message).
   - `test_resume_rehearses_before_reentering`
   - `test_resumed_claude_turn_records_fresh_coverage`
   - `test_resume_leaves_remaining_block_in_planned_order`
7. **Task-input store (G5).** `verify_store` accepts a reviewed
   `interrupted-input` manifest kind that the recovery record binds: the
   observed inventory, which must be a subset of the tree the archive and
   candidate patch reproduce. Trees are never moved.
   - `test_verify_store_accepts_bound_interrupted_verifier_tree`
   - `test_verify_store_rejects_unbound_interrupted_tree`
8. **Audit and seal binding.**
   - `test_cohort_audit_binds_every_host_recovery`
   - `test_cohort_audit_rejects_unbound_host_recovery`
   - `test_seal_covers_every_slot_after_host_recovery` (the v2 outcome seal is
     not `None`).
   - `test_progress_record_binds_host_recoveries`
9. **End to end and runbook.**
   - Extend `tests/test_stage_a_cohort_e2e.py`: interrupt a three-task fixture
     cohort at each class, recover, complete, audit and seal. Assert 21 slots,
     3 per arm, one disposition each.
   - Extend `scripts/run_scheduler_preflight.py` with a SIGKILL checkpoint
     before the boundary and one after it.
   - Add the recovery block verbatim to
     `tests/test_stage_a_archive_cohort_runbook.py`.

Slice 0 can merge on its own. Slices 1–9 form one epic. The epic gate
(`make check`) runs once on the integrated commit.

## Rollout

- **Admission.** Dispatch requires the admitted commit. This feature therefore
  applies only to a cohort admitted at a commit that contains it, which means
  re-admission at step 0, fresh research and provider admission, image
  requalification (`stage_a_native.py` changes break the successor proof), a
  new freeze and owner approval.
- **Cohorts already running.** A cohort admitted earlier keeps today's
  behavior: an interruption leads to retirement.
- **Before launch.** Rehearse provider-free on the execution host with the
  fixture cohort: `systemctl --user kill -s KILL` plus a real reboot at C1 and
  at C2. Record the boot IDs and the classifier output.

## Rollback

- **Code.**
  - Each slice is a separate commit.
  - The recovery path activates only when a recovery record exists, so
    reverting it restores the fail-closed stop.
  - A cohort admitted at the feature commit cannot switch code mid-run. Its
    rollback is the existing *Retire a stopped attempt* procedure; the ledger
    and records are retained as evidence.
- **A single recovery.**
  - An unconsumed resume record can be superseded by a terminal record.
  - A terminal record already applied to the ledger is final. It can be
    reversed only by retiring the attempt (an owner decision), never by
    editing the ledger or the records.
- **Audit failure.** If the audit rejects recovery evidence: stop, retain
  everything, and obtain an owner disposition. Nothing is regenerated.

## Documentation disposition when implemented

- **New ADR 0035**, "Recover a host-interrupted Stage A attempt by its
  provider-contact boundary". It amends ADR-0016's stop rule: resuming a
  reservation before contact is not a replay, and an attempt past contact is
  terminal as `host_interrupted`. The owner must accept it before slice 6
  merges.
- **`CONTEXT.md`**: *Host interruption* and *Interrupted-attempt recovery*.
- **v5 contract** passage (lines 202–213).
- **Continuous-cohort runbook**: the *Stop and resume* section.
- **This plan** then moves to `docs/historical/`.

## Open questions for the owner

1. Should a C0/C1 resume need a per-event owner record (proposed), or count as
   an operator recovery like enrollment renewal?
2. Is `finished_at` = new boot's start time acceptable as the reported upper
   bound for failure-inclusive time, or should interrupted slots be excluded
   from time summaries and listed separately?
3. Should regrading a finished-but-ungraded C2 attempt get its own ADR, or
   stay terminal?
