# Research MCP Sidecar Recovery Decision

## Status

Proposed recovery boundary and staged implementation plan. This document does not
change the implemented recovery behavior described in
[Bounded shared research MCP](../authoritative/research-mcp.md) or
[Owner research trial allowances](../authoritative/owner-research-trials.md).

## Decision

For a supervised standalone research MCP process that disappears during a trial,
fail closed: close the bridge/client, mark the trial interrupted, retain the trial
directory, `started` marker and bounded evidence, and do not restart the sidecar
under that trial identity. A sidecar loss terminates the standalone trial; it does
not create a new quota, silently resume with empty state, or retry an uncertain
research operation.

Do not implement restart recovery in the standalone MCP host while it uses
`VolatileWorkLedger`. The existing owner-managed research-trial path is the only
credible basis for a restart-capable trial: it has durable SQLite reservations,
immutable trial/policy/artifact identity and conservative treatment of uncertain
work. It is a different integration from the standalone MCP process and should
not be described as an MCP restart guarantee. If restartable MCP trials become a
product requirement, first make the MCP service an adapter over that durable
owner-managed authority, or introduce an equivalently durable trusted service;
never add an independent snapshot-and-restore quota ledger to the sidecar.

This decision chooses trial-integrity over availability in the standalone
contract. A workflow can be deliberately re-admitted as a new trial only with a
new authorized identity, explicit limits and new setup. That is not a recovery
of the interrupted trial.

## Existing contracts that constrain recovery

### Standalone MCP bridge, socket, and process

- The native client launches `bridge.js` with one absolute Unix-socket path. The
  bridge validates that the path is a socket owned by its UID with no group or
  other permissions, connects once, and copies stdin/stdout. It does not retry,
  perform a service-generation handshake, or choose a session.
- `main.js` receives trusted setup JSON on inherited descriptor 3 and the Brave
  credential on descriptor 4. Both inputs are bounded and closed after
  bootstrap. The provider credential does not enter argv, environment, MCP
  arguments, or public stdin. The trusted supervisor keeps setup, credential,
  control descriptors and service paths outside agent workspaces/environments.
- The service makes a mode-0600 socket inside a supervisor-owned mode-0700
  directory. That path is a capability selecting the service; it is not a
  model-selectable session ID. The standalone service owns one immutable session,
  policy, volatile ledger and cache namespace.
- Sidecar startup creates `started` exclusively (`wx`) and synchronizes it
  before listening. The marker remains after crash or orderly shutdown, and a
  second startup in that directory is refused. This is intentional: a new
  `VolatileWorkLedger` would reset allowance. A bridge reconnect to the same
  still-running service preserves its in-memory allowance and handles; reconnect
  is not service restart.
- JSON-RPC IDs are connection-local correlation IDs, not replay tokens. MCP
  reconnects create new core calls. Disconnect cancels that connection's work;
  uncertain reservations remain charged. Service restart loses transient
  document handles. The supported recovery is to stop the client/bridge, retain
  evidence and marker, and mark the trial interrupted.

The socket-mode and owner checks do not contain an unrestricted process running
as the same UID. The existing threat boundary depends on supervisor isolation,
separate trial mounts/namespaces and hidden sockets. A recovery design must not
claim that Unix permissions alone isolate a same-UID agent.

### Owner-managed production trial is a distinct path

Owner research trials share one SQLite-backed durable `WorkLedger` across
planner and implementer sessions. Immediate transactions reserve the maximum
before effects; unfinished reservations count as `uncertainMaximum`, and failures,
cancellation and unknown outcomes do not free the reservation. Replacement
sessions do not replenish the allowance. After owner restart, exact replay can
return retained evidence only where the durable dispatcher has it; restart or
result eviction otherwise returns unavailable without repeating network work.
Document handles remain transient; callers refetch with a new call ID and an
expected digest when identity matters. Runtime/policy/artifact drift rejects
admission rather than relabeling loaded code.

The production owner supervises a private broker subprocess over inherited
pipes, not this MCP Unix-socket sidecar. Broker exit fences new admission and
fails pending calls; the owner broker is launched with a credential-bearing
bootstrap descriptor and sanitized environment. Owner restart/recovery reuses
the durable trial assignment and SQLite state. These owner guarantees cannot be
borrowed by the standalone MCP host, whose ledger is volatile and whose marker
intentionally prevents same-directory restart.

## Why not transparently restart the standalone sidecar?

A replacement process started with the old setup and limits would begin with a
fresh volatile ledger. The marker currently prevents precisely that quota reset.
Removing the marker, copying a prior in-memory count, or trusting a supervisor
snapshot cannot establish whether a provider request took effect immediately
before the crash. Replaying it can duplicate an external effect, while treating
it as free can exceed a frozen trial budget.

Reusing the old socket pathname is also unsafe as a session boundary. The
current bridge has no generation handshake, and a new listener at the same path
would serve its new process-owned session to any client with access to that path.
The current marker blocks this reuse; a retry loop or systemd auto-restart that
clears/replaces the directory would undermine it.

A crash also destroys transient document handles and the process's credential
memory. A restart cannot restore handles as if they were valid, nor should it
copy a credential out of logs, process state, agent configuration or trial
artifacts. A trusted supervisor can obtain a credential again from its enrolled
credential provider, but that solves only secret delivery, not accounting,
request ambiguity, or client/session identity.

## Safe restart design, if later required

A safe design is possible only as a new durable service contract, not as a
restart flag on `main.js`:

1. **Keep accounting in the trusted owner.** Every admitted logical call and
   bounded work effect must be reserved transactionally in the existing trial
   ledger before side effects. Unfinished effects retain their reserved maximum.
   The sidecar must not accept client-supplied limits, restore usage from a
   writable file, or create a new ledger for an existing trial. Exact replay
   returns original retained evidence or `unavailable`; it never repeats an
   uncertain provider effect. A deliberate retry is a new call and consumes the
   remaining allowance. No automatic retry occurs after process loss.
2. **Fence the service generation.** The durable owner binds trial ID, session
   capability, policy/source-policy identity, artifact digest, deadline and
   generation. Recovery performs an owner-authorized compare-and-swap to a new
   generation. Old generations cannot reserve work or reconcile results. Setup
   bytes and limits are re-derived from the frozen owner record, not resubmitted
   by a client.
3. **Never reuse the capability path.** Each generation receives a newly
   provisioned private directory and unique socket pathname, hidden from every
   other trial. The client bridge's immutable configuration points only at its
   assigned generation. Do not repoint or restart an old client against a new
   socket. Add a server-generation/session binding handshake before tool calls;
   a stale bridge/client identity is rejected even if configuration or mount
   isolation is accidentally wrong. Only the trusted supervisor chooses that
   binding; the model cannot supply a trial or generation selector.
4. **Fail pending work closed.** On child exit, close the old socket and bridge,
   settle each pending client operation as unavailable, preserve its durable
   reservation as uncertain, and fence the old generation. Never make an MCP
   request appear successful after its response was lost. After deliberate
   recovery, clients may make explicit new calls under the same durable
   assignment and remaining allowance. Old document handles are invalid; refetch
   uses a new call and `expectedDocumentDigest`.
5. **Rebootstrap secrets through the supervisor only.** The trusted supervisor
   reacquires the provider credential from its encrypted credential source and
   sends it once over a fresh bounded inherited descriptor. Keep it out of
   argv, environment, workspace, MCP protocol, readiness, diagnostics and
   durable records. If trusted credential reacquisition or setup validation
   fails, leave the trial fenced/interrupted. Do not cache a plaintext
   credential for recovery.
6. **Retain compact audit state.** Record only service generation, typed exit /
   interruption reason, frozen identity, call/effect identities, outcome and
   accounting. Do not persist page bodies, provider secrets, complete queries,
   handles, or unbounded stderr. Mark every interrupted trial visibly; do not
   misreport an unknown outcome as zero work or provider failure.

The current bridge is intentionally transparent and has neither an identity
handshake nor reconnect/replay protocol. Safe restart therefore needs an
explicitly versioned bridge/service protocol and immutable supervisor-provided
client configuration; it cannot be achieved by adding a blind reconnect loop.

## Staged implementation plan

### Stage 0 — Preserve the current fail-closed boundary (selected now)

- Keep the marker, volatile ledger and same-directory restart refusal.
- Ensure the supervisor reacts to sidecar exit by closing client/bridge activity,
  marking the whole standalone research trial interrupted and retaining compact
  diagnostics and marker. Do not clear the marker automatically.
- Ensure benchmark orchestration does not silently start a replacement service
  with the old trial identity or continue and count the trial as complete.
- Continue to use the owner-managed SQLite trial path for restartable production
  workflows; do not describe it as restart support for the standalone MCP.

### Stage 1 — Verify and make interruption observable

Add deterministic supervisor-level tests before changing lifecycle behavior:

- Kill the standalone process before readiness, while a call is in flight, and
  after a provider effect but before its response. In each case, bridge/client
  observes closure, the trial becomes interrupted, and no replacement service
  accepts the old identity.
- Assert the `started` marker survives `SIGKILL`, normal shutdown and startup
  failure after marker creation; startup in the same directory continues to
  refuse. Evidence preservation must not include page bodies or secrets.
- Verify a bridge connected to a still-live service can reconnect without losing
  that service's allowance, while a process restart is never mistaken for that
  supported reconnect case.
- Assert the credential canary is absent from argv, environment, MCP traffic,
  readiness, stderr, logs and persisted trial evidence. The supervisor's only
  credential source remains its encrypted enrollment path.

This stage documents and tests existing semantics. It requires no sidecar code
change unless an uncovered supervisor integration gap is found.

### Stage 2 — Prove durable recovery prerequisites

Before any availability implementation, exercise owner-trial crash boundaries
using the real SQLite ledger and compiled broker path:

- crash after logical-call reservation, after effect reservation, after provider
  effect, before reconciliation, and after reconciliation/before client reply;
- verify aggregate and role counters never decrease, each unknown maximum stays
  charged, replay never starts another provider effect, and a new explicit call
  is admitted only within remaining aggregate/role/deadline limits;
- verify frozen trial, policy/source policy, cohort, runtime artifact and cache
  identity survive owner recovery; drift and expired deadline fail closed;
- verify stale generation calls and cross-trial/session handles are rejected.

Prefer delegating MCP calls through this existing durable owner boundary. If that
cannot satisfy standalone client requirements, stop for an explicit owner
architecture decision before adding another durable ledger or schema.

### Stage 3 — Implement opt-in same-trial service recovery only after approval

- Specify and version the generation handshake, durable owner APIs and state
  transitions first. Have the trusted owner authorize a new generation
  transactionally while preserving the same trial ledger and frozen identity.
- Provision a new private directory/socket path and immutable client config per
  generation. Keep old paths unavailable and never unlink/recreate a path while
  any old client can use it. Add identity rejection tests for stale sessions.
- Restart the service only from owner-derived setup and fresh descriptor-based
  credential delivery. Keep restart bounded (at most one supervised attempt per
  interruption episode) and do not retry provider calls.
- On restart or identity uncertainty, remain interrupted; do not fall back to
  volatile mode, newly generated limits, or weaker isolation.

Restart support is not enabled by default until every gate above passes and an
owner accepts the added service/client protocol and operational complexity.

### Stage 4 — Rollout, monitoring, and rollback

Canary only deterministic fixtures first, then a separately authorized
credential-backed smoke if required. Compare no-restart behavior with the
restart-capable path on crash timing, uncertain usage, stale-client rejection,
credential redaction, and recovery completion; do not use live provider calls
for broad fault matrices. A live run must use a fresh trial identity and the
existing encrypted credential enrollment, and retain only compact evidence.

Rollback disables generation restart and returns to Stage 0 behavior. Preserve
all trial databases, reservations, markers, evidence and generation directories
until the trial is conclusively ended and evidence retained. Never roll a
ledger/database backward, delete the marker to recover allowance, reuse a socket
path, or continue the interrupted trial on a prior artifact. If a runtime
rollback is needed, select one complete previously admitted artifact for a new
authorized trial; do not mix bridge, core and supervisor versions under the old
trial identity.

## Verification gates

Existing focused suites relevant to Stage 0 are:

```zsh
npx vitest run src/research/mcp/process.test.ts src/research/mcp/protocol.test.ts
npx vitest run src/research/ownerTrial.test.ts src/research/toolDispatcher.test.ts
npm run typecheck
```

The first command proves standalone bootstrap secrecy, marker/restart refusal,
transport semantics, limits and transient-handle behavior. The second proves
durable owner-trial reservations/replay/recovery and process-dispatcher behavior.
A safe-restart implementation additionally requires the fault-injection,
per-generation socket, stale-client, credential-canary, uncertain-accounting and
artifact-drift tests listed above, plus the credential-free packaged MCP smoke.
The opt-in provider smoke verifies credential delivery and live service only; it
does not replace accounting, stale-client or crash-boundary fixtures.

## Unresolved owner decisions

- Is standalone benchmark/MCP trial availability worth introducing a durable
  owner-mediated service and versioned client-generation handshake, or is
  explicit interruption the intended product contract? This proposal recommends
  interruption unless there is a demonstrated availability need.
- If same-trial restart is approved, should MCP remain a transport facade over
  the owner trial ledger, or should the trusted owner expose a dedicated durable
  research service? The standalone sidecar must not independently own trial
  accounting either way.
- What external benchmark-runner signal and artifact format are required to
  record `interrupted` without treating the trial as a completed observation?
