# Research MCP sidecar loss — recovery boundary

**Status:** Speculative decision and staged plan. Nothing here is implemented.
Current behavior is in [Bounded shared research MCP](../authoritative/research-mcp.md)
and [Owner research trial allowances](../authoritative/owner-research-trials.md).

## Question

The standalone research MCP host is a supervised `main.js` sidecar, reached by
native clients through `bridge.js` over a private Unix socket. What happens when
that supervised process disappears while a trial is running (crash, OOM kill,
cgroup kill, host signal)? Should the boundary be fail-closed trial termination,
or can the sidecar be restarted without resetting quota, exposing the provider
credential, or letting a stale client attach to a new session?

## Decision

**Fail-closed trial termination stays the boundary.** Sidecar loss ends that
trial. The supervisor stops the client and bridge, keeps the directory and the
`started` marker, records the trial as interrupted with conservative accounting,
and never relaunches under the old identity. This matches the existing contract.
The first two stages below close gaps in how that contract is enforced.

**A restart is admissible only as a new generation with durable accounting outside
the sidecar.** No current contract meets that condition, so restart is deferred
(Stage 3). It needs an owner decision and work in the separate
`agent-harness-evals` repository, which owns standalone durable recovery.
Hot-restarting the sidecar behind a live client is rejected outright.

Ablation decision: `not_required`. This is failure and safety behavior, not a
quality mechanism. Stage 3 would still change trial comparability, so whether
any cohort may permit a restart is a `needs_owner_decision` cohort question,
not a flag.

## Contracts the decision rests on

Read at the merge of the MCP integration-transport boundary
(`f7c0394`, package 1.3.0).

| Contract | Current behavior | Consequence on loss |
| --- | --- | --- |
| Accounting | `main.js` builds a `VolatileWorkLedger` from setup `limits`; usage and reservations exist only in process memory (`src/research/core/work.ts`). | All usage is lost. Only completed calls leave compact evidence on stderr via `record`. In-flight reservations leave nothing. With four connections of four pending calls each, up to 16 calls and their provider/fetch/elapsed maxima are unaccounted for. |
| Replay | Core call IDs are `<random connection UUID>:<frame count>` (`protocol.ts`). Reconnect IDs are new calls. | Nothing can be replayed across a restart. Every re-issued request is a new charge, which is correct only if the ledger survives. |
| Handles | Document handles are transient and bound to session, capability and policy. | They are lost. A continuation returns `document_unavailable`, and a refetch needs a new call. |
| Restart guard | `startSidecar` creates `started` exclusively and synced before `listen`. It never removes it, even on graceful close. | Relaunch in the same directory fails, so the volatile allowance cannot be silently reset there. |
| Credential | The Brave key arrives on inherited fd 4. Setup JSON arrives on fd 3. Both are bounded, closed after bootstrap, and never on argv, env or stdin. | **Gap:** `runSidecar` reads fd 3 and fd 4 and builds the engine before `startSidecar` checks the marker. A relaunch that will be refused has already received the key. Verified 2026-10-15: a non-fixture launch against an existing marker exits with `research_sidecar_unavailable_or_trial_already_started:sidecar`, which is past the `credential` phase. |
| Diagnostics | `EEXIST` is not in the diagnostic allowlist. | **Gap:** the supervisor cannot tell "already started" apart from other socket-phase failures. |
| Bridge attachment | The bridge checks only that the path is absolute, is a socket, has mode `0600` and is owned by its UID. It then pipes bytes. Neither the bridge nor MCP `initialize` carries a session or generation identity. When the socket closes, the bridge exits. | Whether a native client relaunches its MCP server is not pinned or verified. If it does, the new bridge attaches to whatever listens at the fixed mount `/run/relayview-research/research.sock`. Today the only protection is the same-directory marker plus the supervisor never re-pointing a live client's mount. |
| Socket file | Graceful `close()` unlinks it. A crash leaves it in place. | After a crash, a reconnecting bridge gets a refused connection and fails closed with `research_bridge_unavailable`. That is acceptable. |
| Owner trials | The production owner path does not use the sidecar. It uses a SQLite `WorkLedger` with immediate transactions; uncertain reservations stay charged at their maximum, and replay after restart returns `unavailable`. | This is the model any safe standalone restart would have to copy. |

## Options compared

| Criterion | Fail-closed termination (selected) | New-generation restart (Stage 3, gated) |
| --- | --- | --- |
| Quota reset | Impossible: the marker blocks relaunch, and a new trial needs a fresh directory, identity and authorization. | Prevented only if the ledger lives outside the sidecar, is durable, and is acknowledged before each effect. Unreconciled rows stay charged at their maximum. Rebuilding usage from stderr evidence is rejected because it undercounts in-flight work. |
| Uncertain work | Recorded as an unknown upper bound, using the Stage 2 journal. | Charged at the reserved maximum in the durable ledger, the same as owner trials. |
| Credential exposure | One delivery per trial, which Stage 1 enforces. | One delivery per generation, each gated by the supervisor's preflight. Exposure grows with the restart budget, so the budget is capped and frozen. |
| Stale client | The client is torn down, and no new session ever appears at its mount. | The generation is bound into the bridge and checked against the sidecar's preamble. The whole client sandbox is replaced, so an old client cannot reach the new generation. |
| Trial validity | One honest `interrupted` outcome. | Generations, losses, uncertain work and lost handles appear in the export. All arms of a cohort need the same restart allowance. |
| What survives | Only evidence. | Allowance and evidence. Handles and the client's conversation do not. |
| Cost | Small; this repository only. | A ledger RPC, a setup v2 schema, a bridge argument change, native client re-verification, and supervisor work in `agent-harness-evals`. |

Teardown is required because a stale client must not reach a new generation, so
the native agent session is lost either way. A restart therefore saves only
the trial's remaining allowance for a resumed client. That is worth building only
if the evidence shows sidecar loss is frequent enough to hurt benchmark completion.
Even then, running that workload through the owner trial path, which is already
durable, may be cheaper than making the standalone host durable.

## Staged plan

Each stage is red-before-green at the named seam, with one focused test per slice.

### Prerequisite — restore a green transport smoke

`npm run verify:research-mcp` fails on `f7c0394`. The compiled `smoke.js:72` asserts
`inventory.tools.length === 2`, but `RESEARCH_TOOLS` also includes
`youtube_transcript`. The package README still says version 1.1.0 and two tools,
and the authoritative packing procedure names a 1.2.0 tarball. This needs a
separate card, because every later stage relies on this smoke as evidence.

### Stage 1 — Stop credential delivery to a refused relaunch (this repository)

1. **Test first** (`src/research/mcp/process.test.ts`): run a non-fixture launch
   into a directory that already has `started`. Expect exit 1 with a distinct
   sanitized `trial_already_started` diagnostic, a startup phase before `trusted_setup`,
   and fd 4 never read. Assert that last point by the writer seeing `EPIPE`, or by
   the phase. It fails today: the phase is `sidecar`.
2. Split `startSidecar` so the private-directory check and exclusive marker
   creation run in `runSidecar` before either descriptor is read. Socket
   listening stays after setup. Add `EEXIST` on the marker as the allowlisted
   `trial_already_started` diagnostic.
3. Trade-off: malformed setup now also uses up the directory. This is accepted,
   because each authorized attempt already needs a fresh directory, and it is
   the conservative direction.
4. Add a crash regression: SIGKILL the fixture sidecar while a slow fixture call is
   pending. Expect the bridge to exit, the client to see the transport close, the
   socket file and marker to remain, and a relaunch to be refused before the
   credential phase.

### Stage 2 — Conservative loss accounting and the supervisor contract

1. **Reservation journal:** on `reserve` and `reconcile`, the sidecar writes allowlisted
   compact records to its supervisor stderr: an opaque reservation ID, the maximum
   or actual work, and no query, URL or handle. On Linux, Node writes to a stderr
   pipe synchronously, so a reservation is visible before its effect starts. The
   test kills the sidecar mid-effect and checks that the supervisor-side fold
   equals the reserved maximum for unreconciled work.
2. **Supervisor contract** (documented here, implemented by the standalone supervisor
   in `agent-harness-evals`, with a reference in `smoke.ts`). When the sidecar
   exits without being asked to:
   - stop the client and bridge sandbox;
   - never bind another directory into that sandbox's mount namespace (use
     private mount propagation);
   - record `interrupted` with the last ready `setupDigest`, the folded journal
     (`confirmed`, `uncertainMaximum`) and `accountingComplete: false` when no
     journal is present;
   - keep the directory and do not relaunch automatically.
3. After both are verified, rewrite the recovery paragraph in `research-mcp.md`
   as a present-tense contract.

### Stage 3 — New-generation restart (gated; do not start without approval)

Entry criteria:
- an owner decision that cohorts may declare a restart allowance;
- evidence of sidecar-loss frequency from real runs;
- an agreed split of work with `agent-harness-evals`;
- a comparison against routing the workload through owner trials instead.

1. **Durable external ledger.** Pass a private ledger channel on an inherited
   descriptor. The sidecar's `WorkLedger` becomes an RPC client with
   `durability: "durable"`. The supervisor owns rows that are committed before
   the RPC acknowledgment, using the `research_trial_work` semantics. The sidecar
   holds no allowance.
2. **Setup contract v2.** Add `trialId` and a monotonic `generation` to the
   setup. `capabilityIdentity` and `setupDigest` include the generation, and
   readiness reports `durability: "durable"` and the generation. Version 1
   stays volatile and is unchanged.
3. **Generation directory.** Each generation gets a fresh `0700` directory with
   its own marker. Directories from earlier generations are retained and never
   reused.
4. **Bridge binding.** Client config passes the expected `setupDigest` as a
   second bridge argument. The sidecar sends one preamble line before MCP bytes.
   The bridge checks it and exits on mismatch. MCP framing and tool schemas do
   not change. This needs native re-verification on Codex 0.144.0 and OpenCode
   1.18.28.
5. **Credential gate.** Before writing fd 4, the supervisor confirms three
   things: the previous process is dead (by PID, start time and boot ID); the
   new directory was created exclusively; and the ledger is non-terminal and
   before its deadline. The key comes only from the systemd credential directory.
6. **Restart budget.** A frozen trial-definition field `sidecarRestarts`, default 0,
   which is the same as fail-closed, with a hard cap of 1. Restarts are never
   automatic beyond the frozen budget. The export lists each generation, its
   loss cause, and the uncertain work it left behind.

## Verification

| Stage | Checks |
| --- | --- |
| All | `npx vitest run src/research/mcp src/research/core/service.test.ts`, `npm run typecheck`, `npm run build`, `git diff --check`, `npm run docs:references` (for doc edits) |
| Prerequisite, 1 | `npm run verify:research-mcp` (both profiles), crash regression, refusal-ordering test |
| 2 | Journal fold under kill-mid-effect; supervisor reference reports `interrupted` and does not relaunch |
| 3 | Ledger durability across SIGKILL, zero quota increase after restart, stale-bridge rejection with a mismatched digest, `npm run verify:research-mcp:native` against both pinned clients, `node test/research-trial-smoke.mjs --fixture` unchanged; the opt-in live smoke only after the operator authorizes one paid search |

## Rollback

- **Stages 1–2:** the package version and artifact digest change. Trials admitted on
  1.3.0 finish on 1.3.0, and artifacts are never mixed. Rollback picks the whole
  previous admitted artifact for a new authorized trial. Marker semantics only
  get stricter, so old directories stay refused under either artifact.
- **Stage 3:** set `sidecarRestarts: 0` for new definitions, or select the v1
  artifact. A v2 trial that is in flight cannot be resumed by v1: mark it
  interrupted. Never roll back or edit the durable ledger to recover allowance,
  because rolling it back loses charged work.

## Open decisions

- Should Stage 3 exist at all, or should restart-sensitive workloads use owner
  trials instead?
- Which repository owns the standalone supervisor's interrupted-trial record format?
- Should the bridge binding (Stage 3, item 4) be pulled forward as defense in depth for
  fail-closed operation? It would also catch a supervisor that rebinds a mount by mistake.
