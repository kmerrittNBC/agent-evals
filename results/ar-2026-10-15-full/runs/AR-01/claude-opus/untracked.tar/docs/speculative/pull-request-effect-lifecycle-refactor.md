# Pull-Request Effect Lifecycle Refactor Plan

Status: proposed implementation plan. Nothing here is implemented. Current
behavior is governed by [the pull-request adapter contract](../authoritative/pull-request-adapter.md)
and the source in `src/pr/`.

## Goal And Bound

Reduce the repeated durable-effect lifecycle in `PullRequestDraftCoordinator`,
`PullRequestReadyCoordinator`, and `PullRequestMergeCoordinator` so that the
no-duplicate-external-effect invariant is implemented and tested in one place.

In scope: the three coordinators, their three stores, the merge helper in
`src/pr/contract.ts`, and their tests. Out of scope: the hosting publication
coordinator, the work-tracker mutation coordinator, provider adapters, API and
CLI projections, schema changes in phase 1, and any new effect kind. Phase 1
is behavior-preserving; behavior changes are listed separately as phase 2
candidates that need their own issue and owner decision.

Ablation decision: `not_required`. This is a refactor of a safety invariant,
not an experimental quality mechanism.

## Current Lifecycle, Observed At The Inspected Head

All three effects follow the same skeleton:

1. resolve or verify authority for an exact candidate;
2. look up the prior record by natural key and reuse its `effectId` and
   `recordedAt`;
3. `admit` inside a SQLite transaction; an existing row with the same intent is
   returned, a different intent throws `pr_<kind>_identity_conflict`;
4. decide whether this caller may dispatch;
5. dispatch at most once, swallowing transport errors because the provider may
   have committed;
6. confirm only from an exact provider observation; otherwise `markUnknown`
   (`pending` to `unknown` only) and throw `<kind>_outcome_unknown`;
7. a caller that may not dispatch only reads and reconciles.

The stores share the ID pattern `^[A-Za-z0-9._:-]{1,128}$`, binding-revision,
repository, ref, revision, and timestamp validation, the `markUnknown` and
idempotent `confirm` SQL shape, `get`, and `unresolved()`.

The step-4 dispatch decision differs, and that is where the variants matter:

| | Draft | Ready | Merge |
|---|---|---|---|
| Natural key | `report_id` | `(binding_id, native_pr_id, head_revision)` | same as Ready |
| Initial state | `pending` | `preflight` | `pending` |
| Dispatch claim | caller's proposed ID won admission and no prior row existed | `preflight` to `pending` compare-and-set (`markDispatching`) | same as Draft |
| Pre-dispatch failure | effect stays `pending`, so it can't be retried | stays `preflight`, so it can be retried | `markUnknown`, so it can't be retried |
| Observation key | branch-pair search | native PR read | native PR read |
| Confirmed payload | `nativePrId` | none | `mergedRevision` |
| Mismatched observation | throws `draft_observation_mismatch` | `unknown` | `unknown` |

Probe tests run during planning (then deleted) confirmed three asymmetries.
Phase 1 must preserve them and pin them as characterization tests:

- **A. A pre-dispatch merge denial is permanent.** `requestExactMerge` throws
  gate errors such as `required_checks_incomplete` before any write. The
  coordinator's `catch` records `unknown`. A later call for the same candidate
  only reads, so it returns `merge_outcome_unknown` even after the gate passes,
  and that exact head can never be merged through this coordinator.
- **B. A draft interrupted before create can't be retried.** If the first
  `findByBranches` throws, or the owner stops after `admit` and before
  `createDraft`, the row stays `pending` with no create sent. Every later call
  treats it as possibly dispatched and returns `create_outcome_unknown`.
- **C. Confirmed records are not short-circuited.** A retry of a confirmed
  effect re-reads the provider. If the read fails, the caller gets
  `<kind>_outcome_unknown` while the durable row stays `confirmed`. The draft
  search uses `state=all`, so a merged or closed draft is still found.

Also relevant:

- Only the draft coordinator has a production caller (`src/api/application.ts`).
  The ready and merge coordinators are internal and unwired.
- No production code calls any PR store's `unresolved()`. Restart recovery
  happens only when an effect is retried.
- Coordinator and store tests create hand-written tables without the
  migration's `CHECK (state IN ...)` constraints. A refactor that wrote
  `preflight` into `pr_merge_effect` would pass those tests and fail in
  production.

## Shared Behavior Versus Effect-Specific Rules

These move into the shared lifecycle:

- ordering: authorize, then admit, then claim, then dispatch, then observe, then
  confirm or record unknown;
- reusing the prior `effectId`/`recordedAt` and turning an identity conflict
  into a refusal before any provider call;
- deciding whether a caller may dispatch (both claim modes, below);
- swallowing a dispatch exception and reconciling by read;
- the reconcile-only path for any caller that may not dispatch;
- treating unreadable, invalid, or non-matching observations as `unknown` and
  never as confirmation;
- error codes of the form `<kind>_outcome_unknown`;
- the store-port contract: `admit`, `claimDispatch`, `markUnknown`, `confirm`.

These stay in each coordinator or adapter:

- **Authority.** Draft resolves the confirmed publication, the frozen policy
  that requires PR CI, and the operator principal (checked in the API layer).
  Ready verifies a policy milestone. Merge verifies a durable Human decision and
  actor. None of these move into the shared module, and the shared module never
  decides authority. It only enforces that `authorize` runs before `admit`.
- **Binding resolution (draft only).** A new effect needs the current enabled
  binding. A retained effect uses its pinned revision, even if that revision is
  now disabled. The repository must match the publication and the binding's
  instance and native ID. The base ref comes from the provider default branch,
  and only on first admission.
- **Preconditions.** Ready requires an open PR whose head, base ref, and base
  revision are exact, and confirms without writing if the PR is already not a
  draft. Merge applies every gate in `requestExactMerge`: strategy,
  mergeability, required checks, latest-per-Human approval rules, no queued
  merge, and exact head and base.
- **Confirmation predicates.** Draft: same repository and refs, same head
  revision, `draft === true`. Ready: open, not a draft, exact head and base.
  Merge: merged, with `head.revision === mergedRevision === headRevision`.
- **Provider rules.** These stay in the adapters: the Gitea `WIP:` title,
  `force_merge: false`, `merge_when_checks_succeed: false`, fast-forward with
  `head_commit_id`, transport limits, and redirect refusal.

## Seams Compared

### Seam 1: Shared store base (persistence only)

Add a generic `EffectTable` helper that owns the transactional admit-or-reuse,
`markUnknown`, idempotent `confirm`, `get`, and `unresolved` SQL. It would be
parameterized by table name, row codec, `sameIntent`, and `validate`. The
coordinators stay as they are.

- For: lowest risk, purely mechanical, and it removes about 60% of each store's
  lines.
- Against: it leaves the dangerous duplication (the dispatch decision, the
  reconcile-only path, and swallow-then-read) spread across three coordinators.
  That is exactly where asymmetries A and B live. It also adds table-name
  string templating to SQL, and it does not concentrate the no-duplicate tests.

### Seam 2: Lifecycle runner over a narrow store port (recommended)

Add `src/pr/effectLifecycle.ts` exporting `runDurableEffect(spec)` and an
`EffectLedger<R>` port. Each existing store implements the port with its own
SQL, unchanged. The spec supplies:

- `kind` (`draft` | `ready` | `merge`) for error codes;
- `claim: "on-admission" | "after-preflight"`, which preserves the current
  Draft/Merge and Ready dispatch decisions exactly;
- `admit()` returning `{ record, fresh }`, where `fresh` is the current
  "no prior row and my proposed ID won" test;
- `preflight(record)` returning `"dispatch"`, `{ confirmed: observation }`, or
  a throw (only used in `after-preflight` mode);
- `dispatch(record)`, `observe(record)`, and
  `classify(record, observation)` returning `"confirmed"`, `"absent"`, or
  `{ conflict: code }`;
- `confirm(record, observation)` mapping to the store's confirm payload.

Merge requires splitting `requestExactMerge` into
`assertExactMergeAdmissible(before, request)` (all gates, no I/O),
`adapter.mergeFastForward`, and `exactMergedIdentity(after, request)`.
`requestExactMerge` stays exported as their composition, so
`src/pr/contract.test.ts` keeps covering every gate unchanged.

- For: the ordering and claim invariant lives in one module and can be tested
  with a fake ledger and provider. Authority and provider rules stay explicit
  per effect. No schema change. Public coordinator classes, options, and return
  types are unchanged, so `application.ts` is untouched.
- Against: the spec has about seven callbacks, so there is a risk of building a
  shallow framework. Draft's pre-admission resolution and its `conflict` throw
  path need care. The callback count is bounded by refusing any field not used
  by at least one of the three effects.

### Seam 3: One polymorphic effect table and coordinator (rejected)

Use one `pr_effect` table with a `kind` discriminator and JSON intent, plus one
coordinator class. This needs a data-migrating table rebuild and merges three
distinct authority types behind a `switch`. Rollback would need a reverse data
migration. It fails the bounded-scope requirement.

### Recommendation

Use Seam 2. Keep Seam 1's SQL helper out of phase 1. Per-store SQL is short,
explicit, and tied to a schema that phase 1 does not touch. Revisit it only if
a fourth effect kind appears.

## Migration Plan (Phase 1, Behavior-Preserving)

Each slice is one commit with a red-then-green test at its seam. Each slice
reruns the focused checks listed under Verification on its exact head.

0. **Characterization first.** Add tests that pin current behavior, including
   asymmetries A, B, and C. Name them `characterization:` so phase 2 flips them
   on purpose. Add a migrated-schema fixture so effect tests run against the
   real `CHECK` constraints instead of hand-written tables.
1. **Runner.** Add `effectLifecycle.ts` and `effectLifecycle.test.ts`, driven
   only by a fake ledger and fake provider covering both claim modes. No
   coordinator changes yet.
2. **Ready.** Move `PullRequestReadyCoordinator` onto the runner in
   `after-preflight` mode. Rename `markDispatching` to `claimDispatch`, or alias
   it. Existing `readyCoordinator.test.ts` must pass unedited.
3. **Merge.** Split `requestExactMerge` as described, then move
   `PullRequestMergeCoordinator` onto the runner in `on-admission` mode. Any
   preflight throw must still record `unknown`, which preserves A.
   `mergeCoordinator.test.ts` and `contract.test.ts` must pass unedited.
4. **Draft.** Keep publication, policy, binding, repository, and base-branch
   resolution in the coordinator ahead of `runDurableEffect`. Map a
   `findByBranches` hit that fails the predicate to
   `{ conflict: "draft_observation_mismatch" }`. That code still throws
   without recording `unknown`. `draftCoordinator.test.ts` and the API
   `pull-request` tests must pass unedited.
5. **Docs.** Add one present-tense sentence to the adapter contract's
   Verification section naming the runner test. Documentation disposition:
   `updated` for that sentence only. Effect behavior is unchanged, so no
   contract text changes.

## Rollback

- Phase 1 changes no schema, table, state vocabulary, or public option.
  Rolling back any slice means reverting its commit. Rows written by new code
  are byte-identical to rows written by old code, so an owner restarted on
  reverted code reconciles them in the same way.
- Revert in reverse slice order. Slices 2 to 4 each depend only on slice 1, so
  a single coordinator can be reverted while the others stay on the runner.
- Keep characterization tests in place through rollback. They are the evidence
  that reverted and refactored code behave the same.

## Phase 2 Candidates (Separate Issue, Owner Decision Required)

- Give Draft and Merge a `preflight` state, fixing A and B. This needs
  migrations that rebuild `pr_draft_effect` and `pr_merge_effect` to widen
  their `CHECK` constraint. Rollback is not a simple code revert: the store
  refuses a database written by a newer schema (`unsupported_schema`), so
  rollback means restoring the pre-migration backup or fixing forward. Old code
  that met a `preflight` row would fail closed (it reads and never dispatches),
  which is safe but stuck.
- Return a `confirmed` record without a provider read, fixing C. This changes
  the API's draft retry semantics and needs a decision on whether a confirmed
  draft that was later closed should still report `confirmed`.
- Add an owner restart sweep over `unresolved()` once ready and merge have
  production callers.

## Tests That Preserve No-Duplicate External Effects

Every test below counts provider writes and asserts the exact count.

Runner (`src/pr/effectLifecycle.test.ts`, fake ledger and provider):

- `dispatches once when the provider commits and the response is lost`
- `a retained intent without proof only observes after restart` (new runner
  instance, same ledger)
- `an admission loser never dispatches in on-admission mode`
- `exactly one of two concurrent preflight claimants dispatches` (deferred
  promises interleaved at `claimDispatch`)
- `a pre-claim failure leaves after-preflight effects retryable`
- `an unreadable or invalid reconciliation keeps unknown and throws outcome_unknown`
- `a non-matching post-dispatch observation is never confirmed`
- `an identity conflict at admission reaches no provider call`
- `authorize failure precedes admission` (no row, no call)

Per effect, against the migrated schema:

- Existing tests stay unedited: `published candidate creates one draft and
  reconciles a lost create response`, `a concurrent draft admission does not
  dispatch a second provider create`, all four `readyCoordinator.test.ts`
  cases, `merge intent precedes dispatch and uncertain retries only observe`,
  and `a concurrent merge admission does not dispatch a second provider merge`.
- New: `characterization: merge pre-dispatch denial pins unknown and never dispatches`.
- New: `characterization: draft interrupted before create never creates on retry`.
- New: `characterization: confirmed effect with unreadable provider reports outcome_unknown`.
- New: `draft branch-pair hit with a different head is a conflict and never creates`.
- New: `merged observation with a different merged revision stays unknown`.
- New: `restart across owner store reopen never redispatches unknown draft, ready, or merge effects`.
  This uses a file-backed store opened through migrations, closed, and
  reopened.

## Verification

Focused checks for every slice, on the exact head:

```zsh
npx vitest run src/pr
npx vitest run src/api/contracts-and-auth.test.ts -t 'pull-request|PR inspection'
npm run typecheck
```

`src/pr/gitea.real.test.ts` is opt-in. Run it once after slice 3, because it
exercises the split `requestExactMerge` composition against a disposable Gitea
repository.
