# Proposed Stage A host-interruption recovery plan

**Status: proposal only; not implemented and not an execution authorization.**

This plan describes a narrow extension to recovery for the approved
`archive-stage-a-cohort/1` Stage A freeze. It does not change or replace an
approved freeze, enable native-attempt retries, authorize live execution, or
weaken the existing fail-closed response to uncertain work.

## Contract and current path

The operative contract is [ADR-0016](../authoritative/adr/0016-screen-stage-a-on-23-reviewed-tasks.md): the prepared reviewed release has exactly 23 ordered tasks, seven standard arms, one repetition and one attempt per arm-task pair: **161 frozen slots (23 per arm)**. The entire cohort runs from one approved v5 freeze, configuration, admission, scheduler ledger and artifact root. There is no between-block go/no-go, task replacement, arm omission or comparison-specific restart. Historical runs are not prefixes of this cohort.

The relevant current path is:

1. **Freeze and approval.** The freeze binds the archive release and ordered task identities, all seven arm definitions, numerical/resource policies, deterministic schedule and `freeze_approval_digest`. The owner approves that exact candidate; publication copies the unchanged approved bytes. `stage_a_launcher.verify_plan` checks the approval, admitted target, arm/configuration digests, corpus and schedule digests, one-attempt limit and execution policy before dispatch.
2. **Slot plan.** `staged_contract_v5.expected_outcome_slot_plan` derives one stable UUID slot per scheduled task/arm/repetition and binds its task revision, arm-manifest digest and `max_attempts`. The freeze's `outcome_contract` binds the full plan digest. The scheduler initializes all 161 records as `pending` under `digest(freeze)`; a reservation binds one stable slot/trial/lease and account reservations. It does not pick a replacement slot after a reservation.
3. **Dispatch and completion.** The launcher locks the ledger, refuses any open reservation, rehearses the next pending slot before reservation, writes `intent.json`, then calls the native worker. It writes completion evidence and records the existing lease with `record_attempt`. If the worker raises or the host disappears, the ledger reservation remains open; the normal resume path refuses with `unreconciled active attempt`. The launcher records `automatic_retry=false` and `charges_refunded=false` when it can catch the interruption. The current policy has one attempt per slot.
4. **Block progress.** `run_cohort_step` writes a chained `cohort-progress/block-NNNN.json` only after a block is settled with no reservation. If a block settled but the process died before its progress record, `_checked_ledger` can write the missing next record as `caught_up=true` from the exact ledger. It cannot settle an active lease or repair a changed/broken chain.
5. **Audit and outcome seal.** The offline cohort audit reconstructs each terminal slot from its retained intent, completion, result, lifecycle and artifact evidence; requires exact frozen schedule, no reservations, safe artifact/task-input inventories, a clean host/execution identity, resources quiescent and a complete ordered progress chain. `seal_stage_a` requires that audit to bind the same freeze and final ledger digest. The task-outcome v2 seal requires exactly one validated terminal result per planned slot; if slots are explicitly `unstarted`, the outer Stage A execution seal can report them but does not create a complete task-outcome seal.

Existing recovery documents establish adjacent but different boundaries:

- [Continuous cohort](stage-a-continuous-cohort.md#stop-and-resume) allows a same-freeze resume after pre-reservation stops and after a clean settled-block/progress-record gap. It explicitly refuses an active or uncertain lease and requires retention, not reset or replay.
- [First-block gate](stage-a-first-block-gate.md#retention-failure-recovery) allows one narrowly evidenced, owner-authorized recovery for an unchanged Claude reservation interrupted before native start and before any provider request. That exception is not a general in-flight recovery rule and does not apply to the 23-task cohort.
- [Stage-aware scheduler](stage-aware-scheduler.md#attempt-completion) makes outcomes terminal unless the frozen retry policy authorizes a retry, and only allows `reconcile_pending` to mark never-reserved pending slots unstarted after the frozen window ends. Neither operation presently reconciles a host-lost active lease.
- [Sandbox incident response](benchmark-sandbox-and-incident-response.md#normal-cleanup-and-interrupted-run-recovery) confirms cleanup must be scoped to retained ownership receipts; cleanup never changes scores, scheduler reservations, charges or trial count.
- [Staged execution host](staged-execution-host.md#memory-identity-across-reboot) demonstrates boot-ID and checkpoint-bound host recovery for its qualification workload. That qualification checkpoint is not a native Stage A attempt checkpoint and cannot justify replaying one.

## Decision: three distinct actions

| Choice | Meaning | Assessment for Stage A |
| --- | --- | --- |
| **Replay** | Reserve a new lease/attempt and start the same arm-task native coding attempt again, or rerun native work under the old lease. | **Reject.** The frozen limit is one attempt. A provider may have received work before the host stopped, so replay can duplicate paid/consumed work, expose different context, or select a better result. It also changes the one-attempt comparison even if the schedule bytes remain unchanged. No ledger reset, reservation refund, attempt renumbering, second lease, or silent candidate substitution is acceptable. |
| **Resume** | Continue the same native process/session from a durable checkpoint, without issuing a new native attempt. | **Not supported for native work.** The current adapters expose no cross-reboot checkpoint with a proof that provider-side work will not be repeated. A future adapter-specific, frozen and tested checkpoint protocol would require a separately reviewed contract; host boot recovery or a saved workspace alone is insufficient. **Supported meaning today:** resume the cohort at the next pending slot once the prior block is cleanly settled, retaining the exact freeze and ledger. Also allow record-only settlement when a valid completion already exists, as detailed below; this does not execute native work. |
| **Terminal failure** | Settle the one existing reservation for the interrupted slot as a typed infrastructure failure, with an unknown/infrastructure-missing primary outcome; continue with later frozen slots only after scoped cleanup and proof. | **Recommended for an interrupted native attempt, conditionally.** It preserves the planned slot and arm denominator, honestly records that capability was not observed, and does not replay. It requires sufficient retained evidence to construct and audit a terminal result, verified quiescence, and owner acknowledgment of the host incident. If those proofs are unavailable, do not fabricate a terminal record: leave the lease open and stop/retire the cohort. |

This choice keeps the 23-task/seven-arm comparison intact as a fixed schedule
and denominator, while distinguishing `attempted` infrastructure-missing slots
from true `unstarted` slots. It does not claim that a failed slot is a capability
zero. The frozen eligibility/failure rules and the absolute disposition gate
remain unchanged.

## Proposed recovery protocol and state transitions

Implement as an explicit, serialized `stage_a_recover_interruption` operation
(or equivalent subcommand), never as an implicit launcher retry. It takes the
same frozen inputs and admitted paths as dispatch plus one recovery intent. It
holds the existing launcher lock across inspection and state mutation. Recovery
is idempotent by freeze digest, slot ID, lease ID and recovery-record digest.

1. **No reservation / slot still pending.** Verify the current freeze, host and
   admission as for normal launch. Do not edit the ledger. Re-export ephemeral
   research/provider leases after reboot and resume the same cohort at that
   pending slot. A failure during pre-reservation rehearsal remains pending.
2. **Reservation open; a complete `completion.json` exists.** Do not call the
   native worker. Verify the lease and intent against the exact in-flight
   ledger attempt; validate completion/result/lifecycle identities, result
   digest and v2 outcome, recorded cleanup, usage/accounting and all artifact
   paths/hashes. If all checks pass, record the existing lease exactly once
   through the normal scheduler transition. This repairs a crash between
   durable completion and scheduler persistence, not a native attempt. If
   completion evidence is incomplete or contradictory, remain stopped.
3. **Reservation open; completion absent; host interruption is established.**
   Produce a versioned recovery intent binding the prior ledger checkpoint,
   freeze/configuration/host-profile/admission digests, slot/lease/attempt,
   incident time and operator identity. Require boot ID change for a reboot
   case, or the existing scoped same-boot ownership/process recovery receipts
   for a host-process failure. Confirm every process/resource owned by this
   attempt is stopped/removed and the runner/image/task-input state is
   quiescent; never use a global prune. Confirm there is no evidence of a
   complete terminal candidate that would require ordinary completion
   reconstruction. Do not infer “no provider request” merely from missing
   stream output.
4. **Commit terminal infrastructure outcome for that lease.** After owner
   acknowledgment and all proofs above, emit immutable
   `stage-a-host-interruption-recovery/1` evidence and typed raw lifecycle
   evidence for `termination.reason=infrastructure_failure`,
   `verifier_result=unavailable`, `delivery.status=unavailable`, with
   primary `unknown` / `infrastructure_missing`. Preserve any safe partial
   stream/candidate evidence with its provenance; do not make a partial patch
   eligible or return hidden verifier information to a native process. The
   normalizer remains authoritative. Persist a completion receipt and invoke
   `record_attempt` for the *same* lease with a stable new error code such as
   `host_interruption`; make the error non-retryable even if a future retry
   policy changes. Keep the reservation's actual provider/research consumption;
   never refund it or reset the allocation ledger. Only after durable terminal
   settlement and confirmed cleanup may the scheduler proceed to the next
   pending frozen slot.
5. **No proof, changed trust input, or damaged evidence.** Make no scheduler or
   artifact repair. Preserve all state, retain the active reservation, and
   stop the cohort. The owner may retire the stopped attempt under the existing
   retirement procedure and seek a new separately approved freeze; that new
   cohort is not pooled or represented as a continuation of this one.

After any successful recovery, ordinary block completion and `caught_up`
progress rules apply. The progress record must bind the recovered terminal
slot and recovery receipt digest. The final cohort audit must validate the
recovery provenance and exact terminal row; the seal must bind the resulting
final ledger and unchanged 161-slot plan. No recovery record may alter the
freeze, schedule, slot-plan, arm set, task set, seed, limits, denominator or
outcome contract.

### State table

| Before | Evidence and proof | Allowed next state | Forbidden action |
| --- | --- | --- | --- |
| `pending`, no attempt/reservation | Normal admission/host checks pass | `pending` → `in_flight` only through normal dispatch | Pre-reserve, skip, replace or mark terminal |
| `in_flight`, completion and all outcome evidence durable | Exact lease/identity/digests validate; cleanup confirmed | Same lease → `terminal` via normal `record_attempt` | Native rerun; new lease; infer completion from a partial artifact |
| `in_flight`, no completion | Interruption attestation, prior ledger digest, host/process/resource quiescence, no contradictory result evidence, owner acknowledgment | Same lease → terminal `infrastructure_failed` / v2 primary unknown | Replay; refund; mark `unstarted`; assign capability zero |
| `in_flight`, process may still run or evidence/trust uncertain | Proof missing or conflicting | Remain `in_flight`; fail closed, no seal | Kill by broad PID sweep, fabricate result, advance block |
| All current block slots settled; progress absent | Exact ledger has next settled block and no reservation | Append next `caught_up=true` progress record | Rewrite prior records or skip index |
| Any pending slot after window end, no in-flight reservation | Existing finite-window reconciliation evidence | Mark only never-reserved pending slots `unstarted` under existing rules | Apply this to a reserved/interrupted slot |

## Trust and durability checks required before implementation

- Re-authenticate the exact published freeze and owner approval digest, target
  admission, launcher configuration, execution commit, host registry identity
  and trusted admitted host-profile digest. Do not fetch origin or substitute a
  newly admitted configuration during this recovery.
- Require scheduler state schema validity and exact `manifest_digest`, stage,
  corpus, seven-arm list, schedule digest, plan digest, stable slot/trial/lease
  identities, one attempt, current event sequence and a single matching active
  reservation. Reject a rewritten ledger, duplicate recovery, another active
  scheduler, or an account-reservation/usage mismatch.
- Require paths to be the admitted target-local ledger, artifact root and
  sibling task-input store. Reject symlinks, traversal, missing files, aliases,
  unexpected files or changed content. Use atomic write + file and directory
  fsync for intent, terminal completion, recovery evidence, ledger and progress
  checkpoints; define ordering so every crash point can be retried idempotently.
- For a reboot, compare the pre-interruption boot identity embedded in durable
  host/process ownership evidence with the current boot identity. For same-boot
  recovery, use attempt-specific PID/start-time/boot and Docker/Inspect ownership
  receipts; unavailable identity is a stop. A changed PID alone is not proof.
- Confirm exact attempt resource ownership and cleanup on the admitted Docker
  endpoint. Preserve logs/evidence first. No broad recovery command may delete
  unrelated resources. Agent and verifier remain quiescent before normalization.
- Verify provider/research usage from authoritative retained ledgers and the
  scheduler's account reservation; retain consumed/unknown usage conservatively.
  Missing telemetry is not zero use and cannot justify a refund or retry.
- Re-export credentials only to the approved volatile tmpfs after reboot. Their
  presence grants no native resume authority. Recheck token/enrollment coverage
  before any *future pending* slot is reserved.
- The cohort audit and seal must independently validate the recovery record,
  reconciliation chronology, raw evidence and hashes. Recovery provenance is
  included in the artifact inventory and immutable seal, not trusted solely
  because the scheduler ledger cites a digest.

## Implementation sequence

1. **Contract-first spec and test seam.** Agree a versioned recovery-record
   schema and exact terminal evidence shape. Extend the frozen-outcome and audit
   design only additively; do not change v5 freeze or existing historical
   artifacts. Define the non-retryable error code independently of retry policy.
2. **Pure classifier.** Add a read-only classifier for `pending`,
   `completion_recordable`, `interruptible_terminal_failure`, and
   `unresolved_stop`. It reports reasons and digests, performs no mutation and
   never invokes a native adapter.
3. **Evidence and process proof.** Add host interruption capture and scoped
   cleanup proof using existing ownership receipts; prove atomic persistence
   ordering and idempotent writes under injected power-loss points.
4. **Record-only settlement.** Implement the completion-present path first,
   reusing normal result validation and `record_attempt` for the same lease.
   Add no new execution path or retry capability.
5. **Terminal failure settlement.** Add the explicit operator-attested path,
   typed v2 infrastructure evidence and same-lease terminal scheduler event.
   Ensure consumed reservations remain accounted and no later policy can make
   this recovery retryable.
6. **Audit, seal and runbook.** Extend the offline cohort audit to authenticate
   exactly one recovery record per recovered lease, validate the post-recovery
   slot/result and bind its digest into progress/audit/seal. Document exact
   inspect, cleanup, restart and stop commands only after their behavior is
   implemented and exercised on fixtures.
7. **Provider-free end-to-end verification.** Run simulated interruption at
   every durable boundary; demonstrate unchanged freeze/slot-plan digests,
   161 planned slots, exactly one attempted/terminal record for the affected
   lease, all seven arms with 23 slots each and successful full audit/seal.
   Do not use paid providers or a comparative trial as implementation tests.

## Test plan

Add focused tests before implementation at these seams:

- **Classifier/state machine:** pre-reservation pending stays pending; completion
  record-only settlement is idempotent; a no-completion interrupted lease
  becomes only typed infrastructure-missing after proof; unresolved process,
  missing proof, malformed identity, and changed freeze remain active/stopped.
- **No replay:** inject a native worker counter and assert recovery never calls
  it; assert no second lease/attempt, no refund, no new trial ID and no
  candidate selection. Reject a second recovery record or changed recovery
  payload for the same lease.
- **Crash boundaries:** crash after reservation, intent, provider-contact
  boundary, partial native output, completion write, scheduler write, block
  progress write, cleanup receipt and recovery-record write. Rerun recovery and
  prove either idempotent settlement or fail-closed preservation, never another
  native invocation.
- **Trust rejection:** wrong boot/PID-start identity, unconfirmed process,
  active foreign resource, changed host key/profile/commit/configuration,
  stale/missing admission, wrong freeze/slot/lease digest, broken event/progress
  chain, changed research ledger, tampered artifact, symlink/path escape,
  duplicate reservation, or partial result must refuse before mutation.
- **Accounting and outcomes:** consumed/unknown use is not refunded; recovery
  outcome normalizes to unknown/infrastructure_missing (not score 0); terminal
  slot has one v2 record with exact frozen task/arm/revision; no hidden score
  reaches the recovery or agent.
- **Cohort audit/seal:** fixtures demonstrate a full 23-task × 7-arm schedule
  retains 161 slots, 23 slots per arm and unchanged freeze, schedule and
  slot-plan digests. Audit/seal accept valid recovery evidence, reject missing
  or duplicate evidence, require all block progress, and preserve the ordinary
  failure behavior for `unstarted` slots.
- **Runbook:** provider-free shell/runbook exercise covers interrupted host,
  fresh boot/credential re-export, scoped resource cleanup, record-only and
  terminal-failure cases, plus refusal/retirement. No model/provider request is
  sent.

Focused existing suites to run alongside the new recovery tests are
`tests/test_stage_a_launcher.py`, `tests/test_stage_a_execution.py`,
`tests/test_stage_scheduler.py`, `tests/test_task_outcomes_v2.py`,
`tests/test_stage_a_cohort_e2e.py`, `tests/test_stage_a_cohort_audit.py`,
`tests/test_stage_a_first_block.py`, `tests/test_stage_a_archive_cohort_runbook.py`
and the task-input retention tests. The repository's `make check` remains the
integrated epic gate, not a substitute for these focused checks.

## Rollback and operational stop

The feature must be additive, schema-versioned and opt-in. Before enabling it,
retain the original ledger, artifacts, task-input store, host journal, image
state and pre-recovery hashes. If classifier, evidence, cleanup, ledger or audit
validation fails, abort before mutation where possible; otherwise preserve the
append-only recovery intent and all evidence, keep the reservation active, and
stop. Never delete recovery evidence, edit the ledger by hand, reinitialize it,
or roll back by replaying the native slot. Disable the recovery command for
future cases while keeping already-written records readable. The existing
continuous-cohort **retire a stopped attempt** procedure is the rollback for an
unresolved/unsafe recovery: owner disposition, preserve/move the complete
attempt evidence as documented, re-admit and create a separately approved new
freeze. The retired cohort is never resumed or pooled with its successor.

## Documentation disposition

This file is a plan, not current operational procedure. If implementation is
approved and verified, reconcile the continuous-cohort stop/resume section,
`CONTEXT.md` recovery vocabulary if needed, the scheduler/outcome contract and
the relevant ADR via a new decision record. Until then, the current rule stands:
an uncertain or active Stage A reservation is never replayed and the cohort
stops fail-closed.
