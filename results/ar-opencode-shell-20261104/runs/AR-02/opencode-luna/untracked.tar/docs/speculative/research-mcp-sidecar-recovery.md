# Research MCP Sidecar Recovery Boundary — Proposed Design

**Status:** Proposed decision and staged implementation plan. No recovery behavior
is implemented by this document. It covers the standalone MCP sidecar in
`src/research/mcp/`, launched by a trial supervisor; it does not change the
owner-managed research broker or the owner research-trial contract.

## Decision

When the standalone MCP sidecar exits during a trial, terminate that trial's
research capability and mark the trial interrupted. Do not automatically restart
the sidecar under the same trial identity, directory, socket path, or client
configuration. Preserve its evidence, `started` marker, and any durable trial
accounting. A later run is a new, explicitly authorized trial with a new identity
and isolated directory.

This is the safe behavior supported by the current contracts. A supervisor restart
that merely replays setup with a fresh in-memory ledger could restore quota after
work has already occurred. The current marker deliberately blocks that path. The
standalone MCP may be made restartable within a trial only after the conditions in
the safe-restart alternative below are designed and verified as one end-to-end
change. Restarting the process alone is not recovery.

## Current contracts that set the boundary

- `main.ts` receives trusted setup over inherited descriptor 3 and the Brave
  credential over descriptor 4. It closes each descriptor after bounded
  bootstrap, creates a `VolatileWorkLedger`, and captures one immutable session,
  policy, capability, cache namespace, and limits. Readiness reports
  `durability: "volatile"`; it does not promise provider availability.
- `sidecar.ts` exclusively creates and syncs `<trial-dir>/started` before
  listening. That marker remains after shutdown or crash. Starting again in the
  same directory fails rather than constructing a fresh allowance. Graceful
  shutdown removes the socket but not the marker; a crash can leave a stale socket
  pathname as well as the marker.
- The socket is a mode-0600 capability in a supervisor-owned mode-0700 directory.
  The bridge validates the absolute socket path, socket type, owner UID, and
  permissions, then connects once. It has no retry loop, session handshake, or
  service-generation check. Connection loss closes that bridge's stdio transport;
  a live bridge does not migrate to a successor service.
- MCP connection IDs are private to the protocol connection; the service call ID
  is generated from a random connection identity and a local counter. Neither is
  a durable retry token. Reconnecting and repeating an operation is a new call,
  not exact replay.
- `ResearchService` keeps its replay map and transient document handles in memory.
  The standalone host's `VolatileWorkLedger` loses reservations on process exit.
  Thus neither the call result nor an uncertain reservation can be reconstructed
  from the standalone setup descriptor.
- The production owner trial has a different contract: SQLite transactions
  durably reserve aggregate and role work before effects; an unreconciled
  reservation counts at its maximum and survives owner restart. Its
  `createOwnerTrialService` binds the shared core to this ledger. That accounting
  does not currently make `main.ts`'s standalone MCP sidecar durable.
- The sidecar receives no credential through the bridge, MCP arguments, public
  stdin, environment, or workspace. The credential arrives once on descriptor 4
  and is used by the trusted engine. It must not be copied to restart files,
  command-line arguments, logs, socket messages, or agent-visible configuration.

## Alternatives

| Choice | Quota and uncertain work | Client/socket behavior | Assessment |
| --- | --- | --- | --- |
| **Fail-closed trial termination (selected)** | Does not claim lost volatile usage is recoverable. The existing marker prevents a fresh allowance under the same standalone directory. Owner-trial SQLite reservations remain available for owner-managed trials. | Existing bridge sees closure and does not reconnect. The supervisor ends the client/trial and retains the old directory and marker. | Matches implemented standalone contracts; simplest auditable boundary. |
| Restart in the same directory with today's setup | Reconstructs a new `VolatileWorkLedger` and new replay/handle state. Any operation admitted before death can disappear from the new quota, and an uncertain effect may be repeated. The marker currently blocks this start. | Reusing the socket path creates a possibility that a newly launched stale-config bridge connects to a different in-memory service. A bridge already connected is closed, but the path itself is not a generation fence. | **Reject.** Removing or bypassing the marker is not a recovery design. |
| Same-trial restart with durable accounting and client fencing | Could preserve a single frozen trial budget if every effect reservation is durable-before-effect, unknown work remains charged, and all restarts bind to the same trial/policy/artifact/deadline. Repeated calls after process loss must be new charged calls unless durable exact result replay is implemented; they must never trigger automatic research retry. | Requires a new service generation and a newly admitted bridge/client attachment. Old socket paths must stay dead and never be rebound. Current static bridge config and MCP protocol provide no generation-authenticated reattach. | Possible future design, but not a supervisor-only change. Not selected until owner approval and end-to-end proof. |

## Required invariants

1. **One allowance per trial.** No process restart, socket reconnect, owner restart,
   or changed directory may reset a frozen trial's counters. A new allowance always
   means a distinct, explicitly authorized trial identity.
2. **Charge before effects.** A restart-capable implementation uses the existing
   durable owner ledger or a separately accepted equivalent: reserve atomically
   before cache/network/scoring effects, retain the maximum on uncertain outcomes,
   and reject duplicate effect reservation. Do not initialize a fresh volatile
   ledger from the original limits.
3. **No transparent call retry.** A disconnected MCP call has an uncertain outcome.
   Recovery may expose the preserved accounting and allow an explicit new call only
   within the remaining budget. It must not replay a tool call automatically. If
   durable result replay is later proposed, it needs a separate stable, trusted
   idempotency contract; JSON-RPC IDs alone are connection-scoped.
4. **No stale attachment.** Every service generation gets a distinct socket path in
   a distinct private directory. Never unlink/rebind an old path to a successor.
   Keep the old directory and marker until the old client is confirmed stopped.
   A successor bridge must be launched by the trusted supervisor with the new
   generation's path and immutable identity. The old bridge's known path must
   resolve only to no service. The current bridge does not support this controlled
   reattachment, so same-trial recovery must also coordinate a client restart or
   remain disabled.
5. **Credential remains outside the client.** A successor obtains the credential
   only by re-resolving the existing trusted encrypted/systemd credential source
   into a fresh bounded inherited descriptor. It must not persist plaintext or
   inherit the prior child's open descriptor. If trusted credential re-delivery,
   identity validation, or redaction cannot be proven, fail closed. The bridge
   remains network-disabled and credential-free.
6. **Frozen identity and artifact.** Recovery must match the original trial,
   capability, policy hash/source profile, deadline, cache namespace, and exact
   admitted MCP/core artifact. Artifact drift or policy mismatch requires the
   original admitted runtime or a separately authorized trial, never mixed files.
7. **Transient data stays transient.** Lost document handles and in-flight results
   are not reconstructed. A later fetch must be a new call, charged to the same
   surviving allowance, and use the expected document digest when source identity
   matters.

## Staged implementation plan

### Stage 0 — Enforce the current fail-closed operational policy

- On sidecar exit, stop the associated native client/bridge, mark the standalone
  trial interrupted, retain its bounded evidence and the exact trial directory,
  and do not restart with that identity.
- For owner-managed trials, retain/export the existing SQLite trial state,
  including uncertain maximums. Do not delete the database, edit reservations, or
  assign a replacement trial to the same workflow.
- A new attempt requires explicit authorization and a new trial/session identity,
  directory/socket, cache namespace, deadline and admitted artifact. Do not call
  this continuation or recovery of the previous trial.

### Stage 1 — Make interruption observable and regression-proof

- Extend the supervising integration (the layer that owns the standalone trial
  lifecycle) to classify unexpected sidecar exit separately from provider/tool
  failure, preserve bounded evidence, and settle the trial as interrupted. Do not
  put secret, raw query, page content, or provider diagnostics in the status.
- Add deterministic process tests for exit before readiness, exit with an
  established connection, and exit during an in-flight call. Assert bridge
  transport closure, cancellation/no late success, retained marker, refusal to
  start again in the same directory, and no secret in argv/environment/output.
- Add a stale-socket test proving a crashed process's old path cannot be treated
  as readiness or silently replaced for the old client.
- Preserve existing owner-trial restart tests as the oracle for durable counters,
  uncertain reservations, exact assignment identity, and export after recovery.

### Stage 2 — Decide whether same-trial restart is worth implementing

Before enabling it, obtain an explicit owner decision on scope and maintenance
cost. Prefer routing a future restartable trial through the already durable
owner-trial service/ledger rather than inventing a second ledger. Confirm that the
supervising host can coordinate client lifecycle and isolated socket mounts; the
standalone MCP package by itself cannot guarantee either durable quota or client
fencing. If that orchestration is unavailable, retain Stage 0 as the permanent
boundary.

### Stage 3 — If approved, implement the complete fenced restart transaction

- Define durable sidecar-attempt generations bound to trial ID, session/capability,
  policy/source-policy identity, artifact digest and deadline. Persist generation
  advancement before publishing a successor socket.
- Bind service accounting to the existing durable work ledger. Test process death
  after each durable reservation and at each provider-effect/reconciliation
  boundary; unresolved work remains charged at its reserved maximum.
- Allocate a fresh private directory and unguessable socket pathname per
  generation. Keep each client mount restricted to its own socket. Never let a
  stale client configuration resolve to a successor socket.
- Have the supervisor explicitly stop/confirm the old bridge and client attachment
  before starting a successor bridge with the new immutable path. The current
  bridge remains one-shot; any reattachment mechanism must be an explicit,
  separately tested client lifecycle, not retry-on-ECONNREFUSED.
- Re-resolve the credential from the trusted encrypted source for the new process
  and pass it only by an inherited descriptor. Close descriptors after bootstrap;
  never keep a plaintext restart copy. Keep the model-facing bridge without
  credentials, policy, budget or session selector arguments.
- Publish ready only after the supervisor verifies the exact artifact and setup
  identity, durable ledger binding, new socket ownership/mode, prior generation
  fencing, and required client lifecycle. A failed gate leaves the trial
  interrupted, not partially recovered.

## Verification and acceptance

All ordinary verification is deterministic and credential-free. Add focused tests
for the Stage 1 process/supervisor boundary and keep the existing MCP,
`ownerTrial`, and storage tests for their owned contracts. A Stage 3 implementation
must additionally cover:

- quota exhaustion before a simulated crash remains exhausted after restart;
- reservations made before crash remain charged at their maximum, including
  provider-attempt and fetched-work dimensions;
- a call whose result was lost is never automatically repeated; an explicit new
  call has a new identity and consumes remaining budget once;
- a pre-restart bridge/socket path cannot connect to, initialize, list tools from,
  or call the successor service, while the authorized fresh bridge can;
- restart rejects trial, policy/source profile, deadline, capability, or artifact
  drift and never combines old and new package files;
- a credential canary is absent from process arguments, inherited environment,
  bridge/client output, socket protocol, stderr diagnostics, and trial evidence;
- process-death injection at every reservation, effect, evidence, socket, and
  readiness boundary leaves either a verified ready generation or an interrupted
  trial, never an ambiguous ready state;
- the complete MCP deterministic transport smoke and native fixtures still preserve
  the current result, budget and network-disabled bridge contracts.

Do not use a paid/live provider smoke to establish crash accounting. If a later
credential-path or provider compatibility change independently requires live
verification, run only the documented opt-in smoke through the trusted credential
path and retain its bounded output.

## Rollback

Rollback of any restart feature disables successor startup and returns to
fail-closed trial termination. Retain the old and new generation directories,
markers, trial database, and exports until the interrupted boundary is reconciled;
never delete usage or lower counters to make a retry fit. A database restore cannot
resume the same trial safely if it discards later reservations. If accounting,
generation fencing, artifact identity, or credential delivery is uncertain,
quarantine the trial and start only a separately authorized trial with a new
identity and fresh allowance. Roll back the complete admitted MCP/core artifact as
one unit; do not mix wrapper and core releases.
