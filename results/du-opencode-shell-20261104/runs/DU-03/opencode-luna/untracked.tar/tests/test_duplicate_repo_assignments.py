import subprocess
import tempfile
import unittest
from pathlib import Path

from src.agent_eval.core import validate_repos


class DuplicateRepoAssignmentTests(unittest.TestCase):
    def make_repository(self, path: Path) -> None:
        path.mkdir()
        subprocess.run(["git", "init", "-q", str(path)], check=True)
        subprocess.run(["git", "-C", str(path), "config", "user.email", "eval@example.test"], check=True)
        subprocess.run(["git", "-C", str(path), "config", "user.name", "Eval"], check=True)
        (path / "file").write_text("content")
        subprocess.run(["git", "-C", str(path), "add", "file"], check=True)
        subprocess.run(["git", "-C", str(path), "commit", "-qm", "pin"], check=True)

    def test_duplicate_name_with_different_paths_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            first = root / "first"
            second = root / "second"
            self.make_repository(first)
            self.make_repository(second)

            with self.assertRaisesRegex(ValueError, "Duplicate --repo assignment"):
                validate_repos([f"relayview={first}", f"relayview={second}"])

    def test_single_assignment_is_preserved(self):
        with tempfile.TemporaryDirectory() as temporary:
            repo = Path(temporary) / "repo"
            self.make_repository(repo)

            validated = validate_repos([f"relayview={repo}"])

            self.assertEqual(list(validated), ["relayview"])
            self.assertEqual(validated["relayview"]["path"], str(repo.resolve()))
            self.assertEqual(len(validated["relayview"]["commit"]), 40)


if __name__ == "__main__":
    unittest.main()
