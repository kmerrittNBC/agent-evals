import tempfile
import unittest
from pathlib import Path

from src.agent_eval.core import tree_digest


class TreeDigestSymlinkTests(unittest.TestCase):
    def test_broken_symlink_target_changes_digest(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            link = root / "link"
            link.symlink_to("missing-a")
            before = tree_digest(root)

            link.unlink()
            link.symlink_to("missing-b")

            self.assertNotEqual(before, tree_digest(root))

    def test_valid_symlink_target_is_included_independently_of_file_content(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "target-a").write_text("same content")
            (root / "target-b").write_text("same content")
            link = root / "link"
            link.symlink_to("target-a")
            before = tree_digest(root)

            link.unlink()
            link.symlink_to("target-b")

            self.assertNotEqual(before, tree_digest(root))


if __name__ == "__main__":
    unittest.main()
