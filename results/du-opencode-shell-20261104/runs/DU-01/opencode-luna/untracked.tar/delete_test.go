package main

import (
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strconv"
	"testing"
)

func TestDeleteTodoRemovesItem(t *testing.T) {
	store := newTestStore(t)
	handler := newAPIHandler(store)
	created := performRequest[Todo](t, handler, http.MethodPost, "/api/todos", `{"title":"Remove me"}`, http.StatusCreated)

	request := httptest.NewRequest(http.MethodDelete, "/api/todos/"+strconv.FormatInt(created.ID, 10), nil)
	response := httptest.NewRecorder()
	handler.ServeHTTP(response, request)
	if response.Code != http.StatusNoContent {
		t.Fatalf("DELETE status = %d, want %d; body: %s", response.Code, http.StatusNoContent, response.Body.String())
	}
	if response.Body.Len() != 0 {
		t.Fatalf("DELETE response body = %q, want empty", response.Body.String())
	}

	listed := performRequest[[]Todo](t, handler, http.MethodGet, "/api/todos", "", http.StatusOK)
	if len(listed) != 0 {
		t.Fatalf("list after delete = %+v, want no todos", listed)
	}
	if _, err := store.Get(created.ID); err != errTodoNotFound {
		t.Fatalf("Get after delete error = %v, want %v", err, errTodoNotFound)
	}
}

func TestDeleteMissingTodoReturnsNotFound(t *testing.T) {
	handler := newAPIHandler(newTestStore(t))
	performRequest[map[string]string](t, handler, http.MethodDelete, "/api/todos/99", "", http.StatusNotFound)
	performRequest[map[string]string](t, handler, http.MethodDelete, "/api/todos/0", "", http.StatusBadRequest)
}

func TestDeletedTodoStaysAbsentAfterStoreReopens(t *testing.T) {
	databasePath := filepath.Join(t.TempDir(), "todos.db")
	store, err := NewStore(databasePath)
	if err != nil {
		t.Fatal(err)
	}
	created, err := store.Create(todoInput{Title: "Remove permanently"})
	if err != nil {
		t.Fatal(err)
	}
	if err := store.Delete(created.ID); err != nil {
		t.Fatal(err)
	}
	if err := store.Close(); err != nil {
		t.Fatal(err)
	}

	reopened, err := NewStore(databasePath)
	if err != nil {
		t.Fatal(err)
	}
	defer reopened.Close()
	if _, err := reopened.Get(created.ID); err != errTodoNotFound {
		t.Fatalf("Get after reopening error = %v, want %v", err, errTodoNotFound)
	}
	todos, err := reopened.List()
	if err != nil {
		t.Fatal(err)
	}
	if len(todos) != 0 {
		t.Fatalf("list after reopening = %+v, want no todos", todos)
	}
}
