import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from src.agent_eval.core import pack_status


class PackStatusRepoFactTests(unittest.TestCase):
    def setUp(self):
        self.pack = {
            "reference_answer": "A substantive answer",
            "sources": [{"title": "source", "url": "https://example.test",
                         "retrieved_at": "2026-10-15", "snapshot_or_excerpt": "evidence"}],
            "repo_facts": [{"repo": "relayview", "commit": "a" * 40}],
            "ambiguities": [],
            "grading_guidance": {"must_check": [], "acceptable_alternatives": [],
                                 "do_not_penalize": []},
            "decision_changing_errors": [],
        }
        self.manifest = {"repos": {"relayview": {"path": "/tmp/relayview",
                                                 "commit": "a" * 40}}}

    def check_pack(self, repo_facts):
        self.pack["repo_facts"] = repo_facts
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "pack.json"
            path.write_text(json.dumps(self.pack))
            with patch("src.agent_eval.core.pack_path", return_value=path):
                return pack_status("IG-02", self.manifest)

    def test_rejects_malformed_repo_facts_without_raising(self):
        malformed = [
            None,
            {},
            [None],
            [{}],
            [{"repo": "relayview"}],
            [{"commit": "a" * 40}],
            [{"repo": "  ", "commit": "a" * 40}],
            [{"repo": "relayview", "commit": 7}],
            [{"repo": "relayview", "commit": "a" * 39}],
            [{"repo": "relayview", "commit": "a" * 41}],
        ]
        for facts in malformed:
            with self.subTest(repo_facts=facts):
                okay, reason = self.check_pack(facts)
                self.assertFalse(okay)
                self.assertIn("repo fact", reason.lower())

    def test_well_formed_repo_fact_keeps_pinned_commit_comparison(self):
        self.assertEqual(self.check_pack([{"repo": "relayview", "commit": "a" * 40}]),
                         (True, "ready"))
        okay, reason = self.check_pack([{"repo": "relayview", "commit": "b" * 40}])
        self.assertFalse(okay)
        self.assertIn("repo pin differs", reason)


if __name__ == "__main__":
    unittest.main()
