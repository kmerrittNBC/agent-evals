package main

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestListTodosCompletedFilterPreservesOrderAndStoredTodos(t *testing.T) {
	handler := newAPIHandler(newTestStore(t))
	created := []Todo{
		performRequest[Todo](t, handler, http.MethodPost, "/api/todos", `{"title":"first open"}`, http.StatusCreated),
		performRequest[Todo](t, handler, http.MethodPost, "/api/todos", `{"title":"first done","completed":true}`, http.StatusCreated),
		performRequest[Todo](t, handler, http.MethodPost, "/api/todos", `{"title":"second open"}`, http.StatusCreated),
		performRequest[Todo](t, handler, http.MethodPost, "/api/todos", `{"title":"second done","completed":true}`, http.StatusCreated),
	}

	tests := []struct {
		name string
		path string
		want []int64
	}{
		{name: "without filter", path: "/api/todos", want: []int64{created[0].ID, created[1].ID, created[2].ID, created[3].ID}},
		{name: "completed", path: "/api/todos?completed=true", want: []int64{created[1].ID, created[3].ID}},
		{name: "incomplete", path: "/api/todos?completed=false", want: []int64{created[0].ID, created[2].ID}},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			got := performRequest[[]Todo](t, handler, http.MethodGet, test.path, "", http.StatusOK)
			if len(got) != len(test.want) {
				t.Fatalf("got %d todos, want %d: %+v", len(got), len(test.want), got)
			}
			for i, todo := range got {
				if todo.ID != test.want[i] {
					t.Errorf("todo at index %d has ID %d, want %d", i, todo.ID, test.want[i])
				}
				if test.name == "completed" && !todo.Completed {
					t.Errorf("completed filter returned incomplete todo %+v", todo)
				}
				if test.name == "incomplete" && todo.Completed {
					t.Errorf("incomplete filter returned completed todo %+v", todo)
				}
			}
		})
	}

	afterFiltering := performRequest[[]Todo](t, handler, http.MethodGet, "/api/todos", "", http.StatusOK)
	if len(afterFiltering) != len(created) {
		t.Fatalf("filtering changed stored todos: got %d, want %d", len(afterFiltering), len(created))
	}
	for i, todo := range afterFiltering {
		if todo.ID != created[i].ID {
			t.Errorf("stored todo at index %d has ID %d, want %d", i, todo.ID, created[i].ID)
		}
	}
}

func TestListTodosRejectsInvalidCompletedFilter(t *testing.T) {
	handler := newAPIHandler(newTestStore(t))
	for _, path := range []string{
		"/api/todos?completed=",
		"/api/todos?completed=TRUE",
		"/api/todos?completed=1",
		"/api/todos?completed=true&completed=false",
	} {
		t.Run(path, func(t *testing.T) {
			response := httptest.NewRecorder()
			handler.ServeHTTP(response, httptest.NewRequest(http.MethodGet, path, nil))
			if response.Code != http.StatusBadRequest {
				t.Fatalf("GET %s status = %d, want %d", path, response.Code, http.StatusBadRequest)
			}
		})
	}
}
